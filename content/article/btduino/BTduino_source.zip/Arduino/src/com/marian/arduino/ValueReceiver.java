package com.marian.arduino;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Bitmap.Config;
import android.os.Environment;
import android.os.SystemClock;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class ValueReceiver extends BTEvent {
	public final int SAVE = 45;
	public final int RESET = 46;
	
	private double value;
	private double min;
	private double max;
	private double integral;
	private double sum;
	private long count;
	private boolean autoexpandbounds = true;
	
	private boolean first;
	
	private TextView tvname;
	private TextView tvvalue;
	private ImageView ivanalog;
	private ImageButton ibanalog;
	private ImageView ivplot;
	private ImageButton ibplot;
	
	private Canvas a_canvas;
	private Bitmap a_bmp;
	private Paint a_paint;
	private int bgcolor;
	private boolean a_ready = false;
	
	private boolean showanalog = false;
	
	private Canvas p_canvas;
	private Bitmap p_bmp;
	private Paint p_paint;
	private boolean p_ready = false;
	
	private boolean showplot = false;
	
	private boolean drawing = false;
	private long lastupdate = 0;
	
	private boolean datalogging = false;
	
	/*private class Sample {
		public Sample(double value, long t) {
			this.value = value;
			this.t = t;
		}
		double value;
		long t;		
	}	*/
	
	private List<Sample> history;
	long start;
	
	public ValueReceiver(String name,ExchangeValues uiactivity) {
		this.name = name;
		this.uiactivity = uiactivity;
		value = 0;
		min = 0;
		max = 0;
		integral = 0;
		sum = 0;
		count = 0;
		first = true;	
		
		history = new ArrayList<Sample>();		
		start = SystemClock.uptimeMillis();
	}
	
	public static boolean isvalid(String message) {
		try {
			Double.valueOf(getvalue(message));
		} catch (Exception e) { return false; }
		
		return true;
	}
	
	@Override
	public boolean canhandle(String s_name, String s_value) {		
		if (s_name.compareToIgnoreCase(name) != 0) return false;
		try {
			Double.valueOf(s_value);
		} catch (Exception e) { return false; }		
		return true;
	}

	private long gettime() {
		return SystemClock.uptimeMillis() - start;
	}
	
	@Override
	public void handle(String s_name, String s_value) {
		try {
			if (s_name.compareToIgnoreCase(name) != 0) return;
			value = Double.valueOf(s_value);
		} catch (Exception e) {return;}
		
		if (autoexpandbounds) {
			if (first) {
				max = value;
				min = value;
				first = false;
			}
			else {
				if (value > max) max = value;
				if (value < min) min = value;			
			}
		}
		
		history.add(new Sample(value,gettime()));
		if (history.size() > 1)
			integral += value * (history.get(history.size()-1).t - history.get(history.size()-2).t);
		sum += value;
		count++;
		updateview();
		
		if (datalogging && uiactivity.getproject().getdatalogging()) try { // TODO try catch
			String sd = Environment.getExternalStorageDirectory().toString();
			String filename = sd + uiactivity.getproject().getfilename(name);
    		
			File myFile = new File(filename);
			
			File dir = myFile.getParentFile();
			dir.mkdirs();
			
			
			if (!myFile.exists()) myFile.createNewFile();
			
			FileWriter f = new FileWriter(myFile,true);
			Date now = new Date();
			f.append(now.getTime() + " " + trimTrailingZeros(value,4) + "\n");
			f.close();
			uiactivity.getproject().setlogged();
		} catch (Exception e) {e.printStackTrace();}
	}

	@Override
	public View createView(Context context) {
		view = new LinearLayout(context);
		
		LayoutInflater mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		mInflater.inflate(R.layout.valuereceiver, (LinearLayout) view, true);
		
		tvname = (TextView) view.findViewById(R.id.tvname);
		tvvalue = (TextView) view.findViewById(R.id.tvvalue);
		ivanalog = (ImageView) view.findViewById(R.id.ivanalog);
		ibanalog = (ImageButton) view.findViewById(R.id.ibanalog);
		ibplot = (ImageButton) view.findViewById(R.id.ibplot);
		ivanalog.setVisibility(showanalog ? View.VISIBLE : View.GONE);		
		ivplot = (ImageView) view.findViewById(R.id.ivplot);
		ivplot.setVisibility(showplot ? View.VISIBLE : View.GONE);	
		
		a_ready = false;
		p_ready = false;
		
		ibanalog.setOnClickListener(new View.OnClickListener() {			
			@Override
			public void onClick(View v) {
				showanalog = !showanalog;
				ivanalog.setVisibility(showanalog ? View.VISIBLE : View.GONE);
				drawanalog();
			}
		});
		
		ibplot.setOnClickListener(new View.OnClickListener() {			
			@Override
			public void onClick(View v) {
				showplot = !showplot;
				ivplot.setVisibility(showplot ? View.VISIBLE : View.GONE);
				drawplot();
			}
		});		
		
		updateview();
		return view;
	}

	@Override
	public void updateview() {
		if ((SystemClock.uptimeMillis() - lastupdate > 10) && !drawing)
			uiactivity.runOnUiThread(new Runnable() {
				@Override
				public void run() {
					drawing = true;
					if (view == null) return;
					tvname.setText(name);
					tvvalue.setText(trimTrailingZeros(value,4));
					if (showanalog) drawanalog();
					if (showplot) drawplot();
					lastupdate = SystemClock.uptimeMillis();
					drawing = false;
				}});
	}
	
	private double getx(double p) {
		return Math.cos(p * 2.0 * Math.PI * 0.7 + 0.5 * Math.PI + 2.0 * 0.15 * Math.PI);
	}
	
	private double gety(double p) {
		return Math.sin(p * 2.0 * Math.PI * 0.7 + 0.5 * Math.PI + 2.0 * 0.15 * Math.PI);
	}
	
	private void drawanalog() {
		ivanalog.post(new Runnable() {
			@Override
			public void run() {
				if (!a_ready) setuppainting_analog();				
				a_paint.setColor(bgcolor);
				a_canvas.drawRect(0, 0, a_bmp.getWidth(), a_bmp.getHeight(), a_paint);
				
				int centery = a_bmp.getHeight() / 2;
				int centerx = a_bmp.getWidth() / 4;
				
				int r = (int) (Math.min(a_bmp.getWidth(), a_bmp.getHeight()) * 0.4);
				double steps = 30;
				a_paint.setStrokeWidth(5);
				
				a_paint.setColor(Color.GRAY);
				for (int i = 0; i < steps; i++) {
					a_canvas.drawLine((float)(centerx + getx(i / steps) * r),(float)(centery + gety(i / steps) * r),(float)(centerx + getx((i+1) / steps) * r),(float)(centery + gety((i+1) / steps) * r), a_paint);
				}
				a_paint.setColor(Color.BLACK);
				double p = getrelativevalue(value);
				a_canvas.drawLine(centerx, centery, (float) (centerx + getx(p) * r),(float)(centery + gety(p) * r), a_paint);
				
				a_paint.setTextAlign(Paint.Align.CENTER);
				a_paint.setTextSize(20);
				a_canvas.drawText(trimTrailingZeros(min,2), (float)(centerx + getx(0) * r),(float)(centery + gety(0) * r + 30.0), a_paint);
				a_canvas.drawText(trimTrailingZeros(max,2), (float)(centerx + getx(1) * r),(float)(centery + gety(1) * r + 30.0), a_paint);
				a_canvas.drawText(String.valueOf((int)(p * 100.0)) + "%", (float)(centerx),(float)(centery + gety(1) * r + 30.0), a_paint);
				
				a_paint.setTextAlign(Paint.Align.LEFT);
				a_paint.setColor(Color.GRAY);
				
				int left = a_bmp.getWidth() / 2 + 40;
				int top = 50;
				
				a_canvas.drawText("n", left, top + 30, a_paint);
				a_canvas.drawText(Character.toString((char)916) + "t", left, top + 60, a_paint);
				a_canvas.drawText("t / n", left, top + 90, a_paint);
				a_canvas.drawText("int", left, top + 120, a_paint);
				a_canvas.drawText(Character.toString((char)216), left, top + 150, a_paint);
				a_canvas.drawText(Character.toString((char)216) + "(" + Math.min(history.size(), 20) + ")", left, top + 180, a_paint);
				left += 70;				
				
				a_canvas.drawText(String.valueOf(history.size()), left, top + 30, a_paint);
				if (history.size() > 1)
					a_canvas.drawText(String.valueOf(history.get(history.size()-1).t - history.get(history.size()-2).t), left, top + 60, a_paint);
				if (history.size() > 1)
					a_canvas.drawText(String.valueOf((int)(history.get(history.size()-1).t / (history.size() - 1))), left, top + 90, a_paint);
				if (history.size() > 0)
					a_canvas.drawText(trimTrailingZeros(integral / history.get(history.size()-1).t,2), left, top + 120, a_paint);
				if (history.size() > 0)
					a_canvas.drawText(trimTrailingZeros(sum / count,2), left, top + 150, a_paint);
				if (history.size() > 0) {
					double v = 0;
					for (int i = Math.max(0, history.size() - 20); i < history.size(); i++)
						v += history.get(i).value;
					a_canvas.drawText(trimTrailingZeros(v / Math.min(history.size(), 20.0),2), left, top + 180, a_paint);
				}
				
				ivanalog.setImageBitmap(a_bmp);
			}
		});
	}
	
	private double getrelativevalue(double v) {
		return Math.min(1,Math.max((v - min) / (max - min),0));
	}
	
	private void drawplot() {
		ivanalog.post(new Runnable() {
			@Override
			public void run() {
				if (!p_ready) setuppainting_plot();				
				p_paint.setColor(bgcolor);
				p_canvas.drawRect(0, 0, p_bmp.getWidth(), p_bmp.getHeight(), p_paint);
				
				p_paint.setColor(Color.GRAY);
				int margin = 30;
				p_canvas.drawLine(margin * 2, margin, margin * 2, p_bmp.getHeight() - margin * 2, p_paint);
				p_canvas.drawLine(margin * 2, p_bmp.getHeight() - margin * 2, p_bmp.getWidth() - margin, p_bmp.getHeight() - margin * 2, p_paint);
				
				if (history.size() <= 2) {
					ivplot.setImageBitmap(p_bmp);
					return;
				}
				
				long now = 0;
				if (history.size() > 0)
					now = history.get(history.size() - 1).t;
				
				double millistopx = 0;
				if (history.size() > 200)
					millistopx = (double)(p_bmp.getWidth() - margin * 3) / (double)(now - history.get(history.size()-200).t);
				else millistopx = (double)(p_bmp.getWidth() - margin * 3) / (double)(now - history.get(0).t);
				
				
				p_paint.setColor(Color.BLACK);				
				for (int i = history.size() - 1; i > 0; i--) {
					if ((now - history.get(i-1).t) * millistopx > p_bmp.getWidth() - margin * 3)				
						break;
					p_canvas.drawLine((float)(p_bmp.getWidth() - margin - (now - history.get(i).t) * millistopx), 
							(float)(p_bmp.getHeight() - margin * 2 - getrelativevalue(history.get(i).value) * (p_bmp.getHeight() - 3 * margin)), 
							(float)(p_bmp.getWidth() - margin - (now - history.get(i-1).t) * millistopx), 
							(float)(p_bmp.getHeight() - margin * 2- getrelativevalue(history.get(i-1).value) * (p_bmp.getHeight() - 3 * margin)), 
							p_paint);
				}
				
				p_paint.setColor(Color.GRAY);
				p_paint.setTextAlign(Paint.Align.RIGHT);
				p_paint.setTextSize(18);
				
				p_canvas.drawText(trimTrailingZeros(max,2), margin * 2 - 5, margin+15, p_paint);
				p_canvas.drawText(trimTrailingZeros(min,2), margin * 2 - 5, p_bmp.getHeight() - margin * 2, p_paint);
				
				p_paint.setTextAlign(Paint.Align.CENTER);			
				
				long step = 10;				
				while (step * millistopx * 6 < p_bmp.getWidth()) {
					step *= 2;
					if (step * millistopx * 6 > p_bmp.getWidth()) break;
					step *= 2.5;
					if (step * millistopx * 6 > p_bmp.getWidth()) break;
					step *= 2;
				}
				
				for (long p = now - now % step; p >= now - (p_bmp.getWidth() - margin * 3) / millistopx && p >= 0; p -= step)
					if (step % 1000 != 0)
					p_canvas.drawText(String.valueOf((double)(p * 0.001)), (float)(p_bmp.getWidth() - margin - (now - p) * millistopx),(float)(p_bmp.getHeight() - margin), p_paint);
					else p_canvas.drawText(String.valueOf((int)(p * 0.001)), (float)(p_bmp.getWidth() - margin - (now - p) * millistopx),(float)(p_bmp.getHeight() - margin), p_paint);
				ivplot.setImageBitmap(p_bmp);
			}
		});
	}
	
	private void setuppainting_analog() {
		Config conf = Bitmap.Config.ARGB_8888; 
		a_bmp = Bitmap.createBitmap(ivanalog.getWidth(), ivanalog.getHeight(), conf);
        a_canvas = new Canvas(a_bmp);
        
		a_paint = new Paint();
		a_paint.setAntiAlias(true);
        
        TypedArray array = uiactivity.getTheme().obtainStyledAttributes(new int[] {  
        	    android.R.attr.colorBackground,
        	}); 
    	bgcolor = array.getColor(0, 0xFF00FF); 
    	array.recycle();        
    	a_ready = true;
	}
	
	private void setuppainting_plot() {
		Config conf = Bitmap.Config.ARGB_8888; 
		p_bmp = Bitmap.createBitmap(ivplot.getWidth(), ivplot.getHeight(), conf);
        p_canvas = new Canvas(p_bmp);
        
		p_paint = new Paint();
		p_paint.setAntiAlias(true);
        
        TypedArray array = uiactivity.getTheme().obtainStyledAttributes(new int[] {  
        	    android.R.attr.colorBackground,
        	}); 
    	bgcolor = array.getColor(0, 0xFF00FF); 
    	array.recycle();        
    	p_ready = true;
	}
	
	public static String trimTrailingZeros(double v, int maxdecimalplaces) {
		if (maxdecimalplaces == 0)
			return String.valueOf((int)v);
		String number = Double.valueOf(v).toString();
		if(!number.contains(".")) {
	        return number;
	    }
		
		if (number.length() - number.indexOf(".") > maxdecimalplaces && maxdecimalplaces != -1) {
	    	number = number.substring(0,number.indexOf(".") + maxdecimalplaces);
	    }
	    
	    while (number.charAt(number.length()-1) == '0') number = number.substring(0,number.length()-1);
	    if (number.charAt(number.length()-1) == '.') number = number.substring(0,number.length()-1);	    
    
	    return number;
	}
	
	public void onCreateContextMenu(ContextMenu menu) {
		menu.add(0, RESET, 0, uiactivity.getResources().getString(R.string.reset));
		menu.add(0, SAVE, 0, uiactivity.getResources().getString(R.string.log));
		menu.findItem(SAVE).setCheckable(true);
		menu.findItem(SAVE).setChecked(datalogging);
	}
	
	public boolean onContextItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case RESET:
			max = value;
			min = value;
			integral = 0;
			sum = 0;
			count = 0;
			history.clear();
			autoexpandbounds = true;			
			start = SystemClock.uptimeMillis();
			updateview();
			return true;
		case SAVE:
			datalogging = !datalogging;			
    		return true;
    		default: return false;
		}
	}

	@Override
	public String getinfo() {
		return String.format(uiactivity.getResources().getString(R.string.about_valuereceiver), name, name);
	}
	
	@Override
	public void save(Editor editor, String prefix) {
		editor.putString(prefix + "/type", "ValueReceiver");
		editor.putString(prefix + "/name", name);
		
		editor.putFloat(prefix + "/value", (float) value);
		editor.putFloat(prefix + "/min", (float) min);
		editor.putFloat(prefix + "/max", (float) max);
		editor.putBoolean(prefix + "/showslider", showanalog);
		editor.putBoolean(prefix + "/showplot", showplot);
		editor.putBoolean(prefix + "/datalogging", datalogging);	
	}

	@Override
	public void load(SharedPreferences settings, String prefix) {
		value = settings.getFloat(prefix + "/value", (float) value);
		min = settings.getFloat(prefix + "/min", (float) min);
		max = settings.getFloat(prefix + "/max", (float) max);
		showanalog = settings.getBoolean(prefix + "/showslider", showanalog);
		showplot = settings.getBoolean(prefix + "/showplot", showplot);		
		datalogging = settings.getBoolean(prefix + "/datalogging", false);
	}
}
