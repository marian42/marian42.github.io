package com.marian.arduino;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Environment;
import android.os.Vibrator;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class EventReceiver extends BTEvent {
	private String value;
	private List<String> history;
	
	private TextView tvname;
	private TextView tvvalue;
	
	private boolean vibrate;
	private boolean toast;
	private boolean datalogging = false;
	
	private static final int SAVE = 666;
	private static final int VIBRATE = 667;
	private static final int TOAST = 668;
	private static final int COPY = 669;
	
	
	public EventReceiver(String name, ExchangeValues uiactivity) {
		super(uiactivity,name);
		history = new ArrayList<String>();
		vibrate = false;
		toast = false;
	}

	@Override
	public boolean canhandle(String s_name, String s_value) {
		if (s_name.compareToIgnoreCase(name) != 0) return false;
		return true;
	}
	
	public static boolean isvalid(String message) {
		if (message.contains(":")) return true;
		return false;
	}

	@Override
	public void handle(String s_name, String s_value) {		
		try {
			if (s_name.compareToIgnoreCase(name) != 0) return;
			value = s_value;
			history.add(value);
			updateview();
			if (vibrate) {
				Vibrator v1 = (Vibrator) uiactivity.getSystemService(Context.VIBRATOR_SERVICE);
				v1.vibrate(400);
			}
			if (toast) {
				uiactivity.runOnUiThread(new Runnable() {
					@Override
					public void run() {
						Toast.makeText(uiactivity,value,Toast.LENGTH_SHORT).show();						
					}
				});
			}
			
			if (datalogging) try {
				String folder = Environment.getExternalStorageDirectory() + "/Bluetooth/";
				if (uiactivity.getproject().issaved()) folder += uiactivity.getproject().getname() + "/";
				Date now = new Date(); 
	    		String filename = folder + Sample.clearfilename(name) + String.format("-%d-%02d-%02d.txt",now.getYear()-100,now.getMonth()+1,now.getDate());
	    		
	    		File dir = new File(folder);
				dir.mkdirs();
				
				File myFile = new File(filename);
				
				if (!myFile.exists()) myFile.createNewFile();
				
				FileWriter f = new FileWriter(myFile,true);
				f.append(now.getTime() + " " + s_value + "\n");
				f.close();
			} catch (Exception e) {e.printStackTrace();}
		} catch (Exception e) {return;}
	}

	@Override
	public View createView(Context context) {
		view = new LinearLayout(context);
		
		LayoutInflater mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		mInflater.inflate(R.layout.eventreceiver, (LinearLayout) view, true);
		
		tvname = (TextView) view.findViewById(R.id.tvname);
		tvvalue = (TextView) view.findViewById(R.id.tvvalue);
		
		updateview();
		return view;
	}

	@Override
	public void updateview() {
		uiactivity.runOnUiThread(new Runnable() {
			@Override
			public void run() {
				if (view == null) return;
				tvname.setText(name);
				tvvalue.setText(value);
			}
		});
	}

	@Override
	public String getinfo() {
		return String.format(uiactivity.getString(R.string.about_eventreceiver),name);
	}
	
	public void onCreateContextMenu(ContextMenu menu) {
		menu.add(0, SAVE, 0, uiactivity.getResources().getString(R.string.log));
		menu.findItem(SAVE).setCheckable(true);
		menu.findItem(SAVE).setChecked(datalogging);
		menu.add(0, VIBRATE, 0, uiactivity.getResources().getString(R.string.vibrate));
		menu.findItem(VIBRATE).setCheckable(true);
		menu.findItem(VIBRATE).setChecked(vibrate);
		menu.add(0, TOAST, 0, uiactivity.getResources().getString(R.string.showtoast));
		menu.findItem(TOAST).setCheckable(true);
		menu.findItem(TOAST).setChecked(toast);
		menu.add(0, COPY, 0, uiactivity.getResources().getString(R.string.copy));
	}
	
	@SuppressWarnings("deprecation") // clipboard
	public boolean onContextItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case VIBRATE:
			vibrate = !vibrate;
			Toast.makeText(uiactivity, (vibrate ? uiactivity.getResources().getString(R.string.vibrateenabled) : uiactivity.getResources().getString(R.string.vibratedisabled)), Toast.LENGTH_SHORT).show();
			return true;
		case TOAST:
			toast = !toast;
			Toast.makeText(uiactivity, (toast ? uiactivity.getResources().getString(R.string.toastenabled) : uiactivity.getResources().getString(R.string.toastdisabled)), Toast.LENGTH_SHORT).show();
			return true;
		case SAVE:
			datalogging = !datalogging;			
    		return true;
		case COPY:
			if(android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.HONEYCOMB) {
			    android.text.ClipboardManager clipboard = (android.text.ClipboardManager) uiactivity.getSystemService(Context.CLIPBOARD_SERVICE);
			    clipboard.setText(value);
			} else {
			    android.content.ClipboardManager clipboard = (android.content.ClipboardManager) uiactivity.getSystemService(Context.CLIPBOARD_SERVICE);
			    android.content.ClipData clip = android.content.ClipData.newPlainText(name, value);
			            clipboard.setPrimaryClip(clip);
			}
			Toast.makeText(uiactivity, String.format(uiactivity.getString(R.string.toast_copied), value), Toast.LENGTH_SHORT).show();
			return true;
    	default: return false;
		}
	}
	
	@Override
	public void save(Editor editor, String prefix) {
		editor.putString(prefix + "/type", "EventReceiver");
		editor.putString(prefix + "/name", name);
		editor.putString(prefix + "/value", value);
		editor.putBoolean(prefix + "/vibrate", vibrate);	
		editor.putBoolean(prefix + "/toast", toast);
		editor.putBoolean(prefix + "/datalogging", datalogging);
	}

	@Override
	public void load(SharedPreferences settings, String prefix) {
		value = settings.getString(prefix + "/value", value);
		vibrate = settings.getBoolean(prefix + "/vibrate", vibrate);
		toast = settings.getBoolean(prefix + "/toast", toast);
		datalogging = settings.getBoolean(prefix + "/datalogging",false);
	}
}
