package com.marian.arduino;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;

import android.os.Bundle;
import android.os.Handler;
import android.annotation.TargetApi;
import android.app.ActionBar;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

@TargetApi(11)
public class SelectDeviceActivity extends Activity {
	ListView list;
	ArrayAdapter<String> devices;
	IntentFilter filter;
	ArrayList<String> addresses;
	String uuid;
	
	private static boolean locked = false;
	
	MenuItem menuItemRefresh;
	
	private static final int REQUEST_ENABLE_BT = 1;
	public static String EXTRA_DEVICE_ADDRESS = "device_address";
	
	private static BluetoothAdapter mBluetoothAdapter;
	
	// Create a BroadcastReceiver for ACTION_FOUND
	private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
	    public void onReceive(Context context, Intent intent) {
	        String action = intent.getAction();
	        // When discovery finds a device
	        if (BluetoothDevice.ACTION_FOUND.equals(action)) {
	            // Get the BluetoothDevice object from the Intent
	            BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
	            // Add the name and address to an array adapter to show in a ListView
	            for (int i = 0; i < addresses.size(); i++)
	            	if (addresses.get(i).equals(device.getAddress())) return;	 
	            devices.add(device.getName() + "\n" + device.getAddress());
	            addresses.add(device.getAddress());
	        }
	    }
	};
	
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        this.requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
        ActionBar actionBar = getActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        
        locked = false;
        
        final Context context = this;
        list = new ListView(this);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				if (locked) return; // Prevent multiple clicks
				locked = true;
				
				stopsearch();
				String address = addresses.get(position);
				
				Intent intent = new Intent();
	            intent.putExtra(EXTRA_DEVICE_ADDRESS, address);

	            // Set result and finish this Activity
	            setResult(Activity.RESULT_OK, intent);
	            finish();
	          }
		});        
        setContentView(list);
            	
        devices = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1); 
    	addresses = new ArrayList<String>();
    	filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
    	// Register the BroadcastReceiver
    	registerReceiver(mReceiver, filter); // Don't forget to unregister during onDestroy
        
    	list.setAdapter(devices);       	
    	
    	mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();    	
    	
    	if (mBluetoothAdapter == null) {
    		Toast.makeText(context, R.string.bt_notsupported, Toast.LENGTH_LONG).show();	
    		finish();
    	}
    	if (!mBluetoothAdapter.isEnabled()) {
    		Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
    	    startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
    	    // -> startsearch() is called in onActivityResult()!
    	}
    	else {
    		startsearch();
    	}
     }
    
	private void addbondeddevices() {
		Set<BluetoothDevice> bondedset = mBluetoothAdapter.getBondedDevices();
		Iterator<BluetoothDevice> it = bondedset.iterator();    		
		while (it.hasNext()) {
			BluetoothDevice device = it.next();
			if (!addresses.contains(device.getAddress())) {
    			devices.add(device.getName() + "\n" + device.getAddress());
	            addresses.add(device.getAddress());
			}
		}
	}
	
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
    	switch (requestCode) {
    	case REQUEST_ENABLE_BT: 
    		if (resultCode == Activity.RESULT_CANCELED) {
                Log.d("Error", "BT not enabled");
        		Toast.makeText(this, R.string.bt_disabled, Toast.LENGTH_LONG).show();	
            }
    		if (resultCode == Activity.RESULT_OK) {
                startsearch();
    		}
    		break;
    	};  
    }
        
    private void startsearch() {
    	addbondeddevices();		
    	
    	mBluetoothAdapter.startDiscovery();
    	setProgressBarIndeterminateVisibility(true);
    	
    	final Context context = this;
        
    	final Handler handler = new Handler();
        handler.postDelayed(new Runnable() { 
             public void run() {
            	stopsearch();
            	
     			if (addresses.size() == 0)
     				Toast.makeText(context, R.string.nodevicefound, Toast.LENGTH_SHORT).show();
             }
        }, 10000);
        
        if (menuItemRefresh != null)
	        menuItemRefresh.setVisible(false);
    }
    
    private void stopsearch() {
    	if (mBluetoothAdapter.isDiscovering())
    		mBluetoothAdapter.cancelDiscovery();    
			setProgressBarIndeterminateVisibility(false);
		if (menuItemRefresh != null) {
		        menuItemRefresh.setVisible(true);
		        menuItemRefresh.setEnabled(true);
		}
    }
    
    public void onDestroy() {
    	super.onDestroy();
    	
    	this.unregisterReceiver(mReceiver);
    	// stopsearch();
    	if (mBluetoothAdapter.isDiscovering())
    		mBluetoothAdapter.cancelDiscovery();    	
    }
    
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.selectdevicemenu, menu);
        
        if (menuItemRefresh == null) {
	        menuItemRefresh = menu.findItem(R.id.itsearch);
	        menuItemRefresh.setVisible(false);
        }
        
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
    	switch (item.getItemId()) {
            case R.id.itsearch:
            	if (!mBluetoothAdapter.isEnabled()) {
            		Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            	    startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            	    // -> startsearch() is called in onActivityResult()!
            	}
            	else startsearch();
            	return true;    
            case android.R.id.home:
            	Intent intent = new Intent(this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
