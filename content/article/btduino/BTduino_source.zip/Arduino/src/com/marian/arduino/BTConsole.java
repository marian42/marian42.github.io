package com.marian.arduino;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;

import android.content.Context;
import android.os.Bundle;
import android.os.Environment;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class BTConsole extends BTActivity {
	// TODO handle a lot of data
	private EditText etinput;
	private LinearLayout llconsole;
	private ScrollView svconsole;
	private ImageButton ibsend;
	
	static boolean showoutgoing = true;
	static boolean autoscroll = true;
	
	
	private void scrolldown() {
		if (!autoscroll) return;
		llconsole.invalidate();
		svconsole.invalidate();		    	
		svconsole.post(new Runnable() {
			public void run() {
	    	svconsole.fullScroll(ScrollView.FOCUS_DOWN);
			}
		});
	}
	
	public void restoreList() {
		final Context context = this;
		runOnUiThread(new Runnable() {
			public void run() {  
				llconsole.removeAllViews();
				if (MainActivity.history.size() == 1 && MainActivity.history.get(0).getContent() == "")
					return;
				for (int i = Math.max(0,MainActivity.history.size() - 30); i < MainActivity.history.size(); i++) {
					llconsole.addView(MainActivity.history.get(i).createView(context));
				}
			}
		});
	}
	
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.setTitle(getString(R.string.btconsole));
		this.setContentView(R.layout.btconsole);
		
		etinput = (EditText) this.findViewById(R.id.etinput);
		llconsole = (LinearLayout) this.findViewById(R.id.llconsole);
		svconsole = (ScrollView) this.findViewById(R.id.svconsole);
		ibsend = (ImageButton) this.findViewById(R.id.ibsend);
		etinput.setOnEditorActionListener(new TextView.OnEditorActionListener() {			
			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				if (actionId == KeyEvent.KEYCODE_ENTER) {
					send();
					return true;
				}
				return false;
			}
		});
		ibsend.setOnClickListener(new View.OnClickListener() {			
			@Override
			public void onClick(View v) {
				send();				
			}
		});
		
		restoreList();
		scrolldown();
		
		etinput.setImeActionLabel(getString(R.string.send), KeyEvent.KEYCODE_ENTER);
	}
	
	private void send() {
		String s = etinput.getText().toString() + "\n";
		etinput.setText("");
		send(s);
		if (autoscroll) scrolldown();
	}
	
	public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.consolemenu, menu);  
        return true;
    }
	
    public boolean onOptionsItemSelected(MenuItem item) {
    	switch (item.getItemId()) {            	
            case android.R.id.home:
            	finish();
                return true;
            case R.id.itclear:
            	MainActivity.history.clear();
            	MainActivity.history.add(new Line("",false));	
            	llconsole.removeAllViews();
            	return true;
            case R.id.itsave:
            	try {
            		String folder = Environment.getExternalStorageDirectory() + "/Bluetooth/";
            		
            		String filename = folder + "log";
            		
        			File dir = new File(folder);
        			dir.mkdirs();
        			
        			File myFile;
        			
        			int i = -1;        			
        			do {    
        				i++;
        				myFile = new File(filename + i + ".txt");
        			} while (myFile.exists());
        			filename += i + ".txt";
        			
        			myFile.createNewFile();
        			FileOutputStream fOut = new FileOutputStream(myFile);
        			OutputStreamWriter myOutWriter = 
        									new OutputStreamWriter(fOut);
        			for (int j = 0; j < MainActivity.history.size(); j++) {
        				Line l = MainActivity.history.get(j);        				
        				String a[] = l.getContent().split("\n");
        				for (int k = 0; k < a.length; k++)
        					myOutWriter.append((l.getout() ? ">> " : "<< ") + a[k] + "\n");
        			}
        			myOutWriter.close();
        			fOut.close();
        			Toast.makeText(getBaseContext(),
        					String.format(getString(R.string.toast_saved), filename),
        					Toast.LENGTH_LONG).show();
        		} catch (Exception e) {
        			Toast.makeText(getBaseContext(),getString(R.string.error_saving),Toast.LENGTH_SHORT).show();
        			e.printStackTrace();
        		}
        		return true;
            case R.id.itdisplayupdown:
            	showoutgoing = !showoutgoing;
            	item.setIcon(showoutgoing ? R.drawable.updown : R.drawable.updown_disabled);
            	updatevisibility();
            	//Toast.makeText(this, showoutgoing ? "Alle Nachrichten anzeigen" : "Nur eingehende Nachrichten anzeigen", Toast.LENGTH_SHORT).show();
            	item.setChecked(showoutgoing);
            	return true;
            case R.id.itautoscroll:
            	autoscroll = !autoscroll;
            	//Toast.makeText(this, autoscroll ? "Automatisches scrollen aktiviert" : "Automatisches scrollen deaktiviert", Toast.LENGTH_SHORT).show();
            	item.setChecked(autoscroll);
            	return true;            
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    
    public void onReceive(String s) {
    	//addtext(s,false);
    	updateconsole();
    }
    
    public void send(String s) {
    	super.send(s);
    	updateconsole();
    }
    
    public void updateconsole() {
    	final Context context = this;
    	runOnUiThread(new Runnable() {
			public void run() {
				if (llconsole.getChildCount() > 50) {
					restoreList();
					scrolldown();
					return;
				}
				Line last = MainActivity.history.get(MainActivity.history.size()-1);
				if (last.getView() == null) {
					llconsole.addView(last.createView(context));
					last.getView().setVisibility(!last.getout() || showoutgoing ? View.VISIBLE : View.GONE);
				}
				else {
					last.updateview();
				}
				scrolldown();
			}
		});
    }
    
    public void updatevisibility() {
    	runOnUiThread(new Runnable() {
			public void run() {    	
				for (int i = 0; i < MainActivity.history.size(); i++) {
					Line l = MainActivity.history.get(i);
					if (l.getView() != null)
						l.getView().setVisibility(!l.getout() || showoutgoing ? View.VISIBLE : View.GONE);
				}
				scrolldown();
			}
    	});
    }
    
    public void addtext(String text, boolean out) {
    	final Context context = this;
    	final String s = text;
    	final boolean o = out;
    	runOnUiThread(new Runnable() {
			public void run() {    	
		    	if (MainActivity.history.get(MainActivity.history.size()-1).getout() == o) {
		    		Line last = MainActivity.history.get(MainActivity.history.size()-1);
		    		last.append(s);
		    		if (last.getView() == null)
		    			llconsole.addView(last.createView(context));		    		
		    	}		    		
				else {
					Line l = new Line(s,o);
					MainActivity.history.add(l);
					llconsole.addView(l.createView(context));
				}
		    	scrolldown();
			}
		});
    }
}