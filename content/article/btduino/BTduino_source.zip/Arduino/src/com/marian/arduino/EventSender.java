package com.marian.arduino;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class EventSender extends BTEvent {
	private TextView tvname;
	private Button btnsend;

	public EventSender(String name, ExchangeValues uiactivity) {
		this.name = name;
		this.uiactivity = uiactivity;		
	}
	
	public static boolean isvalid(String message) {
		 return message.startsWith("registerevent:");
	}
	
	@Override
	public boolean canhandle(String s_name, String s_value) {
		return (s_name.compareToIgnoreCase("registerevent") == 0 && s_value.compareToIgnoreCase(name) == 0);
	}

	@Override
	public void handle(String message) {
		
	}

	private void send() {
		uiactivity.send("event:" + name +"\n");
	}

	@Override
	public View createView(Context context) {
		view = new LinearLayout(context);
	
		LayoutInflater mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		mInflater.inflate(R.layout.eventsender, (LinearLayout) view, true);
		
		tvname = (TextView) view.findViewById(R.id.tvname);
		btnsend = (Button) view.findViewById(R.id.btnsend);
		
		tvname.setText(name);
		btnsend.setText(name);
		btnsend.setOnClickListener(new View.OnClickListener() {			
			@Override
			public void onClick(View v) {
				send();				
			}
		});
		
		return view;
	}

	@Override
	public void updateview() {
		
	}

	@Override
	public String getinfo() {
		return "Event senden\n\nBeispiel (Senden):\nevent:" + name + "\n\nBeispiel (Empfangen):\nregisterevent:" + name;
	}
	
	@Override
	public void save(Editor editor, String prefix) {
		editor.putString(prefix + "/type", "EventSender");
		editor.putString(prefix + "/name", name);
	}

	@Override
	public void load(SharedPreferences settings, String prefix) {		
	}
}
