package com.marian.arduino;

import java.util.ArrayList;
import java.util.List;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Bitmap.Config;
import android.graphics.Paint.Style;
import android.os.Environment;
import android.os.SystemClock;
import android.os.Vibrator;
import android.text.InputType;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class Joystick extends BTEvent {
	private final int INVERTX = 48;
	private final int INVERTY = 49;
	private final int AUTOCENTER = 50;
	private final int ADDMOVEMENT = 51;
	private final int SQUARE = 52;
	private final int LOCKX = 53;
	private final int LOCKY = 54;
	
	private double x;
	private double y;
	
	private boolean invertx = false;
	private boolean inverty = false;
	private boolean autocenter = true;
	private boolean square = true;
	private boolean lockx = false;
	private boolean locky = false;
	private boolean hapticfeedback = true;
	
	private int centerx;
	private int centery;
	private int rpad;
	
	private boolean showjoystick;
	
	private TextView tvname;
	private ImageView ivjoystick;
	private ImageButton ibjoystick;
	private ImageButton ibrecord;
	private ImageButton ibplay;
	private ImageButton ibfullscreen;
	
	private Canvas canvas;
	private Bitmap bmp;
	private Paint paint;
	private int bgcolor;
	private boolean ready = false;
	
	private long last = 0;
	private final int cooldown = 60;
	private boolean skipped = false;
	private boolean skipthreadrunning = false;
	
	private boolean recording = false;
	private boolean playing = false;
	
	private List<Sample> path;
	long start;
	
	FullscreenJoystick fullscreen = null;
	

	public Joystick(String name, ExchangeValues uiactivity) {
		this.name = name;
		this.uiactivity = uiactivity;
		x = 0;
		y = 0;
		showjoystick = false;	
	}
	
	public static boolean isvalid(String message) {
		 return message.startsWith("requestjoystick:");
	}
	
	@Override
	public boolean canhandle(String s_name, String s_value) {
		return s_name.compareToIgnoreCase("requestjoystick") == 0;
	}

	@Override
	public void handle(String message) {
		send();
	}		
	
	void send() {
		boolean skip = false;
		if (SystemClock.uptimeMillis() - last < cooldown) {
			skip = true;
			skipped = true;
			if (!skipthreadrunning) {
				skipthreadrunning = true;
				Thread skipthread = new Thread(new Runnable() {
					@Override
					public void run() {
						while (last + 5000 > SystemClock.uptimeMillis()) {
							if (skipped && last + cooldown < SystemClock.uptimeMillis()) {
								send_helper();								
							}
							try {
								synchronized (this) {
									this.wait((long) (cooldown * 1.5));
								}										
							} catch (InterruptedException e) {						
								e.printStackTrace();
							}
						}								
						skipthreadrunning = false;						
					}});
				skipthread.start();
			}
		}
		if (!skip) send_helper();		
	}
	
	void send_helper() {
		uiactivity.send(name + ":" + ValueReceiver.trimTrailingZeros((invertx ? -1.0 : 1.0) * x, 3) + "|" + ValueReceiver.trimTrailingZeros((inverty ? -1.0 : 1.0) * y, 3) + "\n");
		last = SystemClock.uptimeMillis();
		skipped = false;
	}

	@Override
	public View createView(Context context) {
		ready = false;
		view = new LinearLayout(context);
		
		LayoutInflater mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		mInflater.inflate(R.layout.joystick, (LinearLayout) view, true);
		
		tvname = (TextView) view.findViewById(R.id.tvname);
		ivjoystick = (ImageView) view.findViewById(R.id.ivjoystick);
		ibjoystick = (ImageButton) view.findViewById(R.id.ibjoystick);
		ibrecord = (ImageButton) view.findViewById(R.id.ibrecord);
		ibplay = (ImageButton) view.findViewById(R.id.ibplay);
		ibfullscreen = (ImageButton) view.findViewById(R.id.ibfullscreen);
		
		tvname.setText(name);
		
		ivjoystick.setVisibility(showjoystick ? View.VISIBLE : View.GONE);
		ibrecord.setVisibility(showjoystick ? View.VISIBLE : View.GONE);
		if (showjoystick) draw();
		
		ibjoystick.setOnClickListener(new View.OnClickListener() {			
			@Override
			public void onClick(View v) {
				showjoystick = !showjoystick;
				ivjoystick.setVisibility(showjoystick ? View.VISIBLE : View.GONE);
				if (showjoystick) draw();
			}
		});
		
		ivjoystick.setOnTouchListener(new View.OnTouchListener() {			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				if (!(event.getAction() == MotionEvent.ACTION_DOWN || event.getAction() == MotionEvent.ACTION_MOVE || event.getAction() == MotionEvent.ACTION_UP))
					return true;
				if (playing) return true;
				
				if (event.getAction() == MotionEvent.ACTION_DOWN) uiactivity.setScrollable(false);
				if (event.getAction() == MotionEvent.ACTION_UP) uiactivity.setScrollable(true);
				
				set((event.getX() - centerx) / rpad,(event.getY() - centery) / rpad);
				
				if (event.getAction() == MotionEvent.ACTION_UP)
					fingerup();			
				
				if (event.getAction() == MotionEvent.ACTION_DOWN) 
					fingerdown();
				
				draw();
				send();	
				return true;
			}
		});
		
		ibrecord.setOnClickListener(new View.OnClickListener() {			
			@Override
			public void onClick(View v) {
				if (!recording) {
					if (path == null) {
						recording = true;
						path = new ArrayList<Sample>();
						path.add(new Sample(0,0,0));
						start = -1;
						playing = false;
						draw();
						updatebuttons();
					}
					else {
						playing = false;
						path = null;
						updatebuttons();
					}
						
				}
				else if (recording) {
					recording = false;
					updatebuttons();
					draw();
				}
			}
		});		
		
		ibplay.setOnClickListener(new View.OnClickListener() {			
			@Override
			public void onClick(View v) {
				if (!playing) {
					playing = true;
					Thread t = new Thread(new Runnable() {
						@Override
						public void run() {
							long s = SystemClock.elapsedRealtime();
							int p = 0;
							while (playing && path != null) {
								if (p < path.size()) {
									if (SystemClock.elapsedRealtime() >= s + path.get(p).t) {
										x = path.get(p).x;
										y = path.get(p).y;
										send();
										if (showjoystick) draw();
										if (fullscreen != null)
											fullscreen.draw();
										p++;										
									}
									else try { synchronized (this) { wait(20);} } catch (InterruptedException e) { e.printStackTrace(); }									
								}
								else playing = false;
							}
							
							x = 0;
							y = 0;
							send();
							
							draw();
							updatebuttons();
						}});
					t.start();
					updatebuttons();
				}
				else {
					playing = false;
				}
			}
		});
		
		final Joystick thisjoystick = this;		
		ibfullscreen.setOnClickListener(new View.OnClickListener() {			
			@Override
			public void onClick(View v) {
				FullscreenJoystick.joystick = thisjoystick;
				Intent intent = new Intent(uiactivity, FullscreenJoystick.class);
				uiactivity.startActivity(intent);
			}
		});
		
		updatebuttons();
		return view;
	}
	
	public void set(double px, double py) {
		x = px;
		y = py;
		
		if (Math.sqrt(x * x + y * y) > 1 && !square) {
			x /= Math.sqrt(Math.pow(x, 2.0) + Math.pow(y,2.0));
			y /= Math.sqrt(Math.pow(x, 2.0) + Math.pow(y,2.0));
		}
		
		if (square) {
			if (x < -1.0) x = -1.0;
			if (x > 1.0) x = 1.0;
			if (y < -1.0) y = -1.0;
			if (y > 1.0) y = 1.0;
		}
		
		if (lockx) x = 0;
		if (locky) y = 0;
		
		if (recording) 
			if (path.size() == 0 || (path.get(path.size() - 1).x != x || path.get(path.size()-1).y != y)) {		
				if (start == -1) start = SystemClock.uptimeMillis();
				path.add(new Sample(SystemClock.uptimeMillis()-start,x,y));	
			}		
	}
	
	public void fingerdown() {
		if (hapticfeedback) {
			Vibrator v1 = (Vibrator) uiactivity.getSystemService(Context.VIBRATOR_SERVICE);
			v1.vibrate(20);
		}		
	}
	
	public void fingerup() {
		if (autocenter) 
			set(0,0);
		if (hapticfeedback) {
			Vibrator v1 = (Vibrator) uiactivity.getSystemService(Context.VIBRATOR_SERVICE);
			v1.vibrate(20);
		}
	}
	
	
	private void setuppainting() {
		Config conf = Bitmap.Config.ARGB_8888; 
		if (ivjoystick.getWidth() == 0) return;
		bmp = Bitmap.createBitmap(ivjoystick.getWidth(), ivjoystick.getHeight(), conf);
        canvas = new Canvas(bmp);
        
		paint = new Paint();
		paint.setAntiAlias(true);
        
        TypedArray array = uiactivity.getTheme().obtainStyledAttributes(new int[] {  
        	    android.R.attr.colorBackground,
        	}); 
    	bgcolor = array.getColor(0, 0xFF00FF); 
    	array.recycle();        
    	ready = true;
	}	
	
	void draw() {
		if (!showjoystick) return;
		ivjoystick.post(new Runnable() {
			@Override
			public void run() {
				if (!ready) setuppainting();
				if (!ready) return;
				paint.setColor(bgcolor);
				
				canvas.drawRect(0, 0, bmp.getWidth(), bmp.getHeight(), paint);
				
				centery = bmp.getHeight() / 2;
				centerx = bmp.getWidth() / 2;
				rpad = (int) (Math.min(centerx, centery) * 0.7);
				int rstick = (int) (rpad * 0.5);
				
				paint.setColor(Color.GRAY);
				paint.setStyle(Style.STROKE);
				paint.setStrokeWidth(4);
				if (!square)
					canvas.drawCircle(centerx, centery, rpad, paint);
				else canvas.drawRect(centerx - rpad, centery - rpad, centerx + rpad, centery + rpad, paint);
				paint.setColor(Color.BLACK);
				if (recording)
					paint.setColor(Color.RED);
				if (playing) {
					paint.setColor(Color.BLUE);
				}
				canvas.drawCircle((float)(centerx + x * rpad), (float) (centery + y * rpad), rstick, paint);
				paint.setStyle(Style.FILL);
				
				ivjoystick.setImageBitmap(bmp);
			}
		});
	}

	@Override
	public void updateview() {		
		draw();		
	}
	
	private void updatebuttons() {
		view.post(new Runnable() {
			@Override
			public void run() {
				if (recording) ibrecord.setImageResource(R.drawable.done);
				else if (path != null) ibrecord.setImageResource(R.drawable.delete);
				else ibrecord.setImageResource(R.drawable.record);
				if (playing) ibplay.setImageResource(R.drawable.stop);
				else ibplay.setImageResource(R.drawable.play);
				ibplay.setVisibility(path != null ? View.VISIBLE : View.GONE);
				ibrecord.setVisibility(View.VISIBLE);				
			}
		});
	}

	@Override
	public String getinfo() {
		return String.format(uiactivity.getString(R.string.about_joystick), name,name);
	}
	
	public void onCreateContextMenu(ContextMenu menu) {
		menu.add(0, SQUARE, 0, (square ? uiactivity.getString(R.string.circle) : uiactivity.getString(R.string.square)));
		menu.add(0, AUTOCENTER, 0, uiactivity.getString(R.string.autocenter));
		menu.findItem(AUTOCENTER).setCheckable(true);
		menu.findItem(AUTOCENTER).setChecked(autocenter);
		menu.add(0, INVERTX, 0, uiactivity.getString(R.string.invertx));
		menu.findItem(INVERTX).setCheckable(true);
		menu.findItem(INVERTX).setChecked(invertx);
		menu.add(0, INVERTY, 0, uiactivity.getString(R.string.inverty));
		menu.findItem(INVERTY).setCheckable(true);
		menu.findItem(INVERTY).setChecked(inverty);
		menu.add(0, LOCKX, 0, uiactivity.getString(R.string.lockx));
		menu.findItem(LOCKX).setCheckable(true);
		menu.findItem(LOCKX).setChecked(lockx);
		menu.add(0, LOCKY, 0, uiactivity.getString(R.string.locky));
		menu.findItem(LOCKY).setCheckable(true);
		menu.findItem(LOCKY).setChecked(locky);
		if (path != null)
			menu.add(0, ADDMOVEMENT, 0, uiactivity.getString(R.string.addmovement));		
	}
	
	public boolean onContextItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case SQUARE:
			square = !square;
			draw();
			return true;
		case AUTOCENTER:
			autocenter = !autocenter;
			return true;
		case INVERTX:
			invertx = !invertx;
			return true;
		case INVERTY:
			inverty = !inverty;
			return true;
		case LOCKX:
			lockx = !lockx;
			if (lockx) {
				x = 0;
				updateview();
				send();
				locky = false;
			}
			return true;
		case LOCKY:
			locky = !locky;
			if (locky) {
				y = 0;
				updateview();
				send();
				lockx = false;
			}
			return true;
		case ADDMOVEMENT:
			if (path == null) return true;
			AlertDialog.Builder alert1 = new AlertDialog.Builder(uiactivity);

        	alert1.setTitle(uiactivity.getString(R.string.addmovement));
        	alert1.setMessage(uiactivity.getString(R.string.prompt_name));

        	int p = 0;
        	while (uiactivity.getevent(name + "_" + p) != null) p++;
        	
        	final EditText input = new EditText(uiactivity);
        	input.setText(name + "_" + p);
        	input.selectAll();
        	input.setSelectAllOnFocus(true);        	
        	alert1.setView(input);
        	input.setInputType(InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        	        	
        	alert1.setPositiveButton("OK", new DialogInterface.OnClickListener() {
        	public void onClick(DialogInterface dialog, int whichButton) {
        		for (int i = 0; i < path.size(); i++) {
        			if (invertx) path.get(i).x = -1.0 * path.get(i).x;
        			if (inverty) path.get(i).y = -1.0 * path.get(i).y;
        		}        		
        		uiactivity.addevent(new PathEvent(input.getText().toString(), name, path, uiactivity));
        	  	}
        	});

        	AlertDialog dialog = alert1.create();
        	dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        	dialog.show();
			return true;		
		default: return false;
		}
	}
	
	public double getx() {
		return x;
	}
	
	public double gety() {
		return y;
	}
	
	public boolean issquare() {
		return square;
	}
	
	public boolean getautocenter() {
		return autocenter;
	}
	
	public boolean isrecording() {
		return recording;
	}
	
	public boolean isplaying() {
		return playing;
	}
	
	public void save(Editor editor, String prefix) {
		editor.putString(prefix + "/type", "Joystick");
		editor.putString(prefix + "/name", name);
		
		editor.putBoolean(prefix + "/invertx", invertx);
		editor.putBoolean(prefix + "/inverty", inverty);
		editor.putBoolean(prefix + "/autocenter", autocenter);
		editor.putBoolean(prefix + "/square", square);
		editor.putBoolean(prefix + "/lockx", lockx);
		editor.putBoolean(prefix + "/locky", locky);
		editor.putBoolean(prefix + "/hapticfeedback", hapticfeedback);
		editor.putBoolean(prefix + "/showjoystick", showjoystick);
		editor.putBoolean(prefix + "/path", path != null);
		
		if (path != null)
		Sample.savePath(path,Environment.getExternalStorageDirectory() + "/Bluetooth/" + Sample.clearfilename(uiactivity.getproject().getname()) + "/" + Sample.clearfilename(name) + ".txt");
	}

	@Override
	public void load(SharedPreferences settings, String prefix) {
		invertx = settings.getBoolean(prefix + "/invertx", invertx);
		inverty = settings.getBoolean(prefix + "/inverty", inverty);
		autocenter = settings.getBoolean(prefix + "/autocenter", autocenter);
		square = settings.getBoolean(prefix + "/square", square);
		lockx = settings.getBoolean(prefix + "/lockx", lockx);
		locky = settings.getBoolean(prefix + "/locky", locky);
		hapticfeedback = settings.getBoolean(prefix + "/hapticfeedback", hapticfeedback);
		showjoystick = settings.getBoolean(prefix + "/showjoystick", showjoystick);
		
		path = null;
		if (settings.getBoolean(prefix + "/path", false))
			path = Sample.loadPath(Environment.getExternalStorageDirectory() + "/Bluetooth/" + Sample.clearfilename(uiactivity.getproject().getname()) + "/" + Sample.clearfilename(name) + ".txt");
	}
}