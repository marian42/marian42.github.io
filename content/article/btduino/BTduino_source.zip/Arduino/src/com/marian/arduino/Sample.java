package com.marian.arduino;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

class Sample {
	// Sample for recordes joystick paths
	public Sample(long t, double x, double y) {
		this.t = t;
		this.x = x;
		this.y = y;
	}
	
	public Sample(double value, long t) {
		this.value = value;
		this.t = t;
	}
	
	long t;
	double x;
	double y;
	double value;
	
	public String toString() {
		return t + " " + x + " " + y;
	}
	
	public static Sample fromString(String s) {
		long t = 0;
		double x = 0;
		double y = 0;
		
		try {
			String[] a = s.split(" ");
			t = Long.valueOf(a[0]);
			x = Double.valueOf(a[1]);
			y = Double.valueOf(a[2]);
		} catch (Exception e) {return null;}
		
		return new Sample(t,x,y);
	}
	
	public static void savePath(List<Sample> path, String filename) {
		File myFile = new File(filename);
		myFile.getParentFile().mkdirs();
				
		FileWriter f;
		try {
			f = new FileWriter(myFile,false);		
			for (int i = 0; i < path.size(); i++)
			f.append(path.get(i).toString() + "\n");
			f.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static List<Sample> loadPath(String filename) {
		List<Sample> path = new ArrayList<Sample>();
		File file = new File(filename);
		if (!file.exists()) return path;
		
		BufferedReader reader = null;
		 
		try {
			reader = new BufferedReader(new FileReader(file));
			String s = null;
		 
			while ((s = reader.readLine()) != null) {
				Sample sample = fromString(s);
				if (sample != null)
					path.add(sample);
			}
			
			reader.close();
		} catch (IOException e) { e.printStackTrace(); }		
		return path;
	}
	
	public static String clearfilename(String p) {
		String allowedchars = "abcdefghijklmnopqrstuvwxyz0123456789-_./";
		String result = "";
		String lowercase = p.toLowerCase();
		for (int i = 0; i < p.length(); i++)
			if (allowedchars.indexOf(lowercase.charAt(i)) != -1)
				result += p.charAt(i);
		return result;
	}
}	