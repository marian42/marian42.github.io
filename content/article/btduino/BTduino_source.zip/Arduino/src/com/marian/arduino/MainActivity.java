package com.marian.arduino;

import java.util.ArrayList;
import java.util.List;

import android.os.Bundle;
import android.os.Handler;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.text.InputType;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends Activity {

	private static final int REQUEST_CONNECT_DEVICE = 1;
	private static final int DELETE = 50;
	private static final int RENAME = 51;
	
	public static BluetoothSerialService mSerialService = null;
	
	private ListView lvtools;
	
	private static MenuItem itconnect;
	
	//public static boolean connected = false;
	
	public static List<Line> history;
	
	private static int state = 0;
	
	public static MainActivity instance;
	
	private static String last;
	private BluetoothDevice currentdevice;
	
	private static String[] tools_names;
	
	private ProgressBar pbconnect;
	private ImageButton ibconnect;
	private ImageButton ibdevices;
	private TextView tvconnect;
	private TextView tvdevice;
	private LinearLayout llconnect;
	
	private static final int REQUEST_ENABLE_BT = 42;
	
	public final static String PREFS_NAME = "Arduino_Prefs";
	
	private static List<BTProject> projects;
	public static BTProject currentproject;
	public static BTProject standardproject;
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        setContentView(R.layout.activity_main);
        
        lvtools = (ListView) this.findViewById(R.id.lvtools);
        
        instance = this;
        
        if (MainActivity.history == null) {
			MainActivity.history = new ArrayList<Line>();
			MainActivity.history.add(new Line("",false));
        }
        
        pbconnect = (ProgressBar) this.findViewById(R.id.pbconnect);
        ibconnect = (ImageButton) this.findViewById(R.id.ibconnect);
        ibdevices = (ImageButton) this.findViewById(R.id.ibdevices);
        tvconnect = (TextView) this.findViewById(R.id.tvconnect);
        tvdevice = (TextView) this.findViewById(R.id.tvdevice);
        llconnect = (LinearLayout) this.findViewById(R.id.llconnect);
        
        // Load saved projects       
        if (projects == null) loadprojects();
        
        // Make List of tools
        updatelist();
        this.registerForContextMenu(lvtools);
        
        final Context context = this;
        llconnect.setOnClickListener(new View.OnClickListener() {			
			@SuppressWarnings("static-access")
			@Override
			public void onClick(View v) {			
	        	if (state != mSerialService.STATE_NONE) {
	        			try {
	        				mSerialService.stop();
	        			} catch (Exception e) { e.printStackTrace(); }	        		
	            }
	        	else {
	        		if (last != "") {
	        			BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter(); 	
	        	    	if (!mBluetoothAdapter.isEnabled()) {
	        	    		Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
	        	    	    startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
	        	    	}
	        			connect(last);
	        		}
	        		else {
	        			Intent intent = new Intent(context, SelectDeviceActivity.class);
		        		startActivityForResult(intent,REQUEST_CONNECT_DEVICE);
	        		}
	        	}
			}
		});
        
        ibdevices.setOnClickListener(new View.OnClickListener() {			
			@Override
			public void onClick(View v) {
				if (mSerialService != null)
					mSerialService.stop();
				Intent intent = new Intent(context, SelectDeviceActivity.class);
        		startActivityForResult(intent,REQUEST_CONNECT_DEVICE);
			}
		});
        
        // Setup Bluetooth
        mSerialService = new BluetoothSerialService(this, new Handler());  
    	
        setbuttonconnect();        
        
        // Restore preferences
        SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
        last = settings.getString("last", "");
        
        autoconnect(last);
        
        lvtools.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@SuppressWarnings("unused")
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int item,
					long arg3) {
				boolean connected = true;
				if (mSerialService == null) connected = false;
				else if (mSerialService.getState() != BluetoothSerialService.STATE_CONNECTED)
					connected = false;				
				// Start tool Activity:
				switch (item) {
				case 0: {
					// Bluetooth Console
					Intent intent = new Intent(context, BTConsole.class);
               		context.startActivity(intent);
					break;
				}					
				case 1: {
					// Exchange Values
					if (standardproject == null) {
						standardproject = new BTProject();	
					}
					currentproject = standardproject;				
					Intent intent = new Intent(context, ExchangeValues.class);
               		context.startActivity(intent);
					break;
				}					
				default: {
					int index = item - tools_names.length;
					currentproject = projects.get(index);				
					Intent intent = new Intent(context, ExchangeValues.class);
               		context.startActivity(intent);
					break;		
				}
				};
			}
		});
        state = mSerialService.getState();
        this.onchangestate(state);
    }
    
    private void loadprojects() {
    	SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
        int count = settings.getInt("projects", 0);
        projects = new ArrayList<BTProject>();
        for (int i = 0; i < count; i++) {
        	int id = settings.getInt("id" + i, -1);
        	String name = settings.getString(id + "/name", "");
        	if (!name.equals("") && id != -1)
        		projects.add(new BTProject(name,id));
        }
    }
    
    public void saveprojects() {
    	SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
	    SharedPreferences.Editor editor = settings.edit();
	    editor.putInt("projects", projects.size());
	    for (int i = 0; i < projects.size(); i++) {
	    	editor.putInt("id" + i, projects.get(i).getid());
	    }	
	    editor.commit();
    }
    
    @SuppressWarnings("unchecked")
	private void updatelist() {
    	if (tools_names == null) {
    		Resources res = getResources();
            tools_names = res.getStringArray(R.array.tools);   
    	}
    	     
    	ArrayAdapter<String> tools = (ArrayAdapter<String>) lvtools.getAdapter();
    	
    	if (tools == null)
    		tools = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1);
    	else tools.clear();
    	
        for (int i = 0; i < tools_names.length; i++)
        	tools.add(tools_names[i]);
        
        if (projects != null) {
        	for (int i = 0; i < projects.size(); i++)
        		tools.add(projects.get(i).getname());
        }
        
        lvtools.setAdapter(tools);        
    }
    
    public static int getnewid() {
    	int id = 0;
    	while (true) {
    		boolean found = false;
    		for (int i = 0; i < projects.size(); i++) 
    			if (projects.get(i).getid() == id)
    				found = true;
    		if (!found) return id;
    		id++;
    	}
    }
    
    public void addproject(BTProject project) {
    	projects.add(project);
    	saveprojects();
    	updatelist();
    }
    
    void setbuttonconnect() {
    	this.runOnUiThread(new Runnable() {
			@Override
			public void run() {
				if (itconnect != null) {
		    		itconnect.setIcon(state == BluetoothSerialService.STATE_CONNECTED ? R.drawable.connected : R.drawable.disconnected);
		    		itconnect.setTitle(state == BluetoothSerialService.STATE_CONNECTED ? getString(R.string.disconnect) : getString(R.string.connect));
		    	}
			}    		
    	});    	
    }
    
    @SuppressWarnings("static-access")
	void onchangestate(int state) {
    	this.state = state;

    	
    	String info_connect = getString(R.string.noconnection);
    	String info_device = getString(R.string.nodevice);
    	boolean button_visible = true;
    	
    	if (currentdevice != null)
    		info_device = (currentdevice.getName() != null ? currentdevice.getName() : getString(R.string.unknown)) + " (" + currentdevice.getAddress() + ")";
    	
    	switch (state) {
    	case BluetoothSerialService.STATE_CONNECTED:
    		info_connect = getString(R.string.status_connected);
    		last = currentdevice.getAddress();
    		break;
    	case BluetoothSerialService.STATE_CONNECTING:
    		info_connect = getString(R.string.status_connecting);
    		button_visible = false;
    		break;
    	case BluetoothSerialService.STATE_LISTEN:
    		info_connect = getString(R.string.status_waiting);
    		break;
    	}
    	
    	if (state == BluetoothSerialService.STATE_NONE) {
    		BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();    	
        	
        	if (mBluetoothAdapter == null) {
        		info_device = getString(R.string.bt_notsupported);
        	}
        	else if (!mBluetoothAdapter.isEnabled()) {
        		info_device = getString(R.string.bt_disabled);        		
        	}
    	}
    	
    	final String final_info_connect = info_connect;
    	final String final_info_device = info_device;
    	final boolean final_button_visible = button_visible;
    	final boolean connected = state == BluetoothSerialService.STATE_CONNECTED;
    	
    	this.runOnUiThread(new Runnable() {    		
			@Override
			public void run() {	
				tvconnect.setText(final_info_connect);
				tvdevice.setText(final_info_device);
				ibconnect.setVisibility(final_button_visible ? View.VISIBLE : View.GONE);
				pbconnect.setVisibility(final_button_visible ? View.GONE : View.VISIBLE);
				ibconnect.setImageResource(connected ? R.drawable.connected : R.drawable.disconnected);
			}    		
    	});
    	
    	setbuttonconnect();    	
    }
    
    public static void addtohistory(String s, boolean out) {
    	if (history.get(history.size()-1).getout() == out) {
    		Line last = history.get(history.size()-1);
    		if (last.getContent().length() > 100) {
    			int p = -1;
    			while (last.getContent().indexOf("\n", p+1) != -1)
    				p = last.getContent().indexOf("\n", p+1);
    			if (p != -1) {
	    			s = last.getContent().substring(p+1) + s;
	    			last.setContent(last.getContent().substring(0,p));
	    		}
    		}
    		else {
    			last.append(s);
    			return;
    		}
    	}
		history.add(new Line(s,out));
    }
    
    @Override
    public void onCreateContextMenu(ContextMenu menu, View view,
        ContextMenuInfo menuInfo) {    	
	    if (view == lvtools) {
	    	AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo)menuInfo;
	    	if (info.position < tools_names.length) return;
	    	int index = info.position - tools_names.length;
	    	menu.setHeaderTitle(projects.get(index).getname());
	    	menu.add(Menu.NONE,DELETE,0,getString(R.string.delete));
	    	menu.add(Menu.NONE, RENAME, 0, getString(R.string.rename));
	   	}
    }
    
    @Override
    public boolean onContextItemSelected(MenuItem item) {
    	AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo)item.getMenuInfo();
    	final int index = info.position - tools_names.length;
    	switch (item.getItemId()) {
    	case DELETE: {
    		projects.remove(index);
        	saveprojects();
        	updatelist();
        	return true;
    	}
    	case RENAME: {
    		AlertDialog.Builder alert = new AlertDialog.Builder(this);

        	alert.setTitle(String.format(getString(R.string.project_rename), projects.get(index).getname()));
        	alert.setMessage(getString(R.string.prompt_newname));

        	final EditText input = new EditText(this);
        	alert.setView(input);
        	input.setText(projects.get(index).getname());
        	input.selectAll();
        	input.setInputType(InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        	input.setSelectAllOnFocus(true);
        	
        	alert.setNegativeButton(getString(R.string.cancel), null);
        	alert.setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
	        	public void onClick(DialogInterface dialog, int whichButton) {
	        		// Rename
	        		projects.get(index).setname(input.getText().toString());
	        		
	        		// Save
	        		SharedPreferences settings = getSharedPreferences(MainActivity.PREFS_NAME, 0);
	        	    SharedPreferences.Editor editor = settings.edit();
	        		projects.get(index).save(editor);
	        		editor.commit();
	        		
	        		saveprojects();
	            	updatelist();
	            }
        	});

        	AlertDialog dialog = alert.create();
        	dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        	dialog.show();
        	return true;    	}
    	
    	default: return false;
    	}
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
       getMenuInflater().inflate(R.menu.activity_main, menu);
        
       return true;
    }
    
    public boolean onOptionsItemSelected(MenuItem item) {
    	switch (item.getItemId()) {        
        default:
            return super.onOptionsItemSelected(item);
        }
    }
    
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
    	switch (requestCode) {
    	case REQUEST_CONNECT_DEVICE: 
    		if (resultCode == Activity.RESULT_OK) {
                String address = data.getExtras().getString(SelectDeviceActivity.EXTRA_DEVICE_ADDRESS);                           
                connect(address);
            }
    		break;
    	case REQUEST_ENABLE_BT:
    		connect(last);
    		break;    	
    	};
    }
    
    public void autoconnect(String address) {
    	if (address == "") return;
    	connect(address);
    }
    
    private void connect(String address) {
    	// Get the BluetoothDevice object
    	BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);
        currentdevice = device;
        
    	// Attempt to connect to the device
        if (mSerialService == null)
        	mSerialService = new BluetoothSerialService(this, new Handler());
        else mSerialService.stop();
        mSerialService.connect(device);
        
		/*final ProgressDialog dialog = new ProgressDialog(this);
	    dialog.setTitle("Verbinden...");
	    dialog.setMessage("Bitte warten...");
	    dialog.show();	    
	    
	    final Context context = this;

	    Thread thread = new Thread((new Runnable() {
    		public void run() {   
    			Looper.prepare();
    			Log.i("status",":" + mSerialService.getState());
    			while (mSerialService.getState() == BluetoothSerialService.STATE_NONE)
					try { Thread.sleep(100); } catch (Exception e) { e.printStackTrace(); }
			    while (mSerialService.getState() == BluetoothSerialService.STATE_CONNECTING)
					try { Thread.sleep(100); } catch (Exception e) { e.printStackTrace(); }
				Log.i("status",":" + mSerialService.getState());	    			
				dialog.dismiss();
    			
    			if (mSerialService.getState() == BluetoothSerialService.STATE_CONNECTED) {
	    			runOnUiThread(new Runnable() {
	    				public void run() {
	    					setbuttonconnect();
	    				}
	    			});
    			}
    			else {
    				runOnUiThread(new Runnable() {
	    				public void run() {
	    					Toast.makeText(context, "Nicht verbunden", Toast.LENGTH_SHORT).show(); 
	    				}
	    			});    				
    			}
    		}
    	}));
    	thread.start();*/
    }
    
    protected void onStop(){
        super.onStop();

	    // We need an Editor object to make preference changes.
	    // All objects are from android.context.Context
	    SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
	    SharedPreferences.Editor editor = settings.edit();
	    editor.putString("last", last);
	
	    // Commit the edits!
	    editor.commit();
     }

}
