package com.marian.arduino;

import java.util.ArrayList;
import java.util.List;

import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.SystemClock;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Log;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class ExchangeValues extends BTActivity {
	private LinearLayout llevents;
	private LockableScrollView svevents;
	
	private static BTProject project;
	private static String line = "";
	
	private boolean first = true;
	private long start;
	
	private BTEvent selected;
	
	public static String nextname;
	
	public final int DELETE = 42;
	public final int BLOCK = 43;
	public final int INFO = 44;
	
	private static String parsestring = "";
	
	private Menu optionsmenu;
	
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.setTitle(R.string.exchange_values);
		
		svevents = new LockableScrollView(this);
		this.setContentView(svevents);
		svevents.setLayoutParams(new FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.MATCH_PARENT));
		llevents = new LinearLayout(this);
		llevents.setLayoutParams(new FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.WRAP_CONTENT));
		llevents.setOrientation(LinearLayout.VERTICAL);
		svevents.addView(llevents);
		
		ActionBar actionBar = getActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
		
        project = MainActivity.currentproject;
        
        if (!project.isloaded()) {
			SharedPreferences settings = getSharedPreferences(MainActivity.PREFS_NAME, 0);
			project.load(settings, this);
		}
        
		if (project == null) {
			finish();			
		}
		
		final ExchangeValues context = this;
		this.runOnUiThread(new Runnable() {
			@SuppressWarnings("deprecation")
			@Override
			public void run() {
				llevents.removeAllViews();
				for (int i = 0; i < project.getevents().size(); i++) {
					View v = project.getevents().get(i).createView(context);
					
					int[] attrs = new int[] { android.R.attr.selectableItemBackground};
					TypedArray ta = obtainStyledAttributes(attrs);
					Drawable drawableFromTheme = ta.getDrawable(0);
					v.setBackgroundDrawable(drawableFromTheme);
					ta.recycle();
					// Src: http://stackoverflow.com/questions/9398610/how-to-get-the-attr-reference-in-code
					
					llevents.addView(v);;
					context.registerForContextMenu(v);
					project.getevents().get(i).setuiactivity(context);
					project.getevents().get(i).updateview();
				}
			}});
		
		start = SystemClock.uptimeMillis();
		
		if (!project.getname().equals(""))
			this.setTitle(project.getname());
	}
	
	public void onReceive(String s) {
		line += s;
		while (line.contains("\n")) {
			receiveEvent(line.substring(0, line.indexOf("\n")));
			line = line.substring(line.indexOf("\n")+1);
		}
	}
	
	public void setScrollable(boolean scrollable) {
		svevents.setScrollable(scrollable);
	}
	
	private float getbatterylevel() {
		IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
		Intent batteryStatus = registerReceiver(null, ifilter);
		
		int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
		int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);

		return level / (float)scale;
	}
	
	private void receiveEvent(String message) {
		if (project == null || project.getevents() == null) return;
		// Skip one line
		if (first) {
			first = false;
			//if (SystemClock.uptimeMillis() - start < 500)
				//return;
		}
		for (int i = 0; i < project.getevents().size(); i++) {
			if (project.getevents().get(i).canhandle(message)) {
				project.getevents().get(i).handle(message);
				return;
			}
		}
		
		if (message.equals("ping")) {
			send("ping\n");
			return;
		}
		
		if (message.trim().equalsIgnoreCase("getbattery")) {
			send("battery:" + String.valueOf((int)(getbatterylevel() * 100)) + "\n");
		}
		
		if (!message.contains(":")) return;
		String a[] = message.split(":");
		if (a.length != 2) return;
		
		if (a[0].equals("remove")) {
			for (int i = 0; i < project.getevents().size(); i++) {
				if (project.getevents().get(i).getname().equals(a[1])) {
					removeEvent(project.getevents().get(i));
					return;
				}
			}
			return;
		}
		
		if (!project.getaddnewevents()) return;
		
		BTEvent btevent = null;
		
		if (ValueReceiver.isvalid(message))
			btevent = new ValueReceiver(a[0],this);
		else if (BooleanSender.isvalid(message))
			btevent = new BooleanSender(a[1],this);
		else if (ColorSender.isvalid(message))
			btevent = new ColorSender(a[1],this);
		else if (StringSender.isvalid(message))
			btevent = new StringSender(a[1],this);
		else if (ColorSender.isvalid(message))
			btevent = new ColorSender(a[1],this);
		else if (Joystick.isvalid(message))
			btevent = new Joystick(a[1],this);
		else if (EventSender.isvalid(message))
			btevent = new EventSender(a[1],this);
		else if (IntegerSender.isvalid(message))
			btevent = new IntegerSender(a[1],this);
		else if (ColorReceiver.isvalid(message))
			btevent = new ColorReceiver(a[0].equals("registercolor") ? a[1] : a[0],this);		
		else if (EventReceiver.isvalid(message))
			btevent = new EventReceiver(a[0],this);
		
		if (btevent != null) {
			addevent(btevent);
			if (btevent instanceof ValueReceiver || btevent instanceof ColorReceiver || btevent instanceof EventReceiver)
				btevent.handle(message);
		}
	}
	
	public void addevent(BTEvent btevent) {
		project.add(btevent);
		final ExchangeValues context = this;		
		final BTEvent btevent_final = btevent;
		this.runOnUiThread(new Runnable() {
			@SuppressWarnings("deprecation")
			@Override
			public void run() {
				View v = btevent_final.createView(context);				
				
				int[] attrs = new int[] { android.R.attr.selectableItemBackground};
				TypedArray ta = obtainStyledAttributes(attrs);
				Drawable drawableFromTheme = ta.getDrawable(0);
				v.setBackgroundDrawable(drawableFromTheme);				
				ta.recycle();
				// Src: http://stackoverflow.com/questions/9398610/how-to-get-the-attr-reference-in-code				
				
				llevents.addView(v);
				context.registerForContextMenu(v);
				btevent_final.updateview();
			}			
		});		
	}
	
	public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
		super.onCreateContextMenu(menu, v, menuInfo);
		
		selected = null;
		for (int i = 0; i < project.getevents().size(); i++)
			if (project.getevents().get(i).getView() == v)
				selected = project.getevents().get(i);
		if (project.getblocked() != null)
			if (project.getblocked().getView() == v)
				selected = project.getblocked();
		if (selected == null) return;
		
		menu.setHeaderTitle(selected.getname());
	    selected.onCreateContextMenu(menu);

	    if (!(selected instanceof BlockEvents))
	    	menu.add(0, DELETE, 0, getString(R.string.delete));
	    if (!(selected instanceof BlockEvents))
	    	menu.add(0, BLOCK, 0, getString(R.string.block)); 
	    menu.add(0, INFO, 0, getString(R.string.about));
	}
	
	public void removeEvent(BTEvent btevent) {
		llevents.removeView(btevent.getView());
		project.remove(btevent);
		if (btevent == project.getblocked()) project.setblocked(null);
	}
	
    public boolean onContextItemSelected(MenuItem item) {
    	switch (item.getItemId()) {  
    	case DELETE:
    		removeEvent(selected);
    		Toast.makeText(this, String.format(getString(R.string.toast_deleted), selected.getname()),Toast.LENGTH_SHORT).show();
    		return true;
    	case BLOCK:    		
    		if (project.getblocked() == null) {
    			project.setblocked(new BlockEvents(this));
    			this.addevent(project.getblocked());
    		}
    		project.getblocked().block(selected);
    		llevents.removeView(selected.getView());
    		project.remove(selected);
    		Toast.makeText(this, String.format(getString(R.string.toast_blocked), selected.getname()), Toast.LENGTH_SHORT).show();
    		project.getblocked().updateview();
    		return true;
    	case INFO:
    		AlertDialog.Builder builder = new AlertDialog.Builder(this);
        	builder.setTitle(R.string.about);
        	builder.setMessage(selected.getinfo());
        	builder.setPositiveButton(R.string.ok, null);
        	        	
        	AlertDialog alert = builder.create();
        	alert.show();
    		return true;
        default:
        	if (selected.onContextItemSelected(item)) return true;
            return super.onOptionsItemSelected(item);
    	}
    }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.exchangevaluesmenu, menu); 
        if (project != MainActivity.standardproject) 
        	menu.removeItem(R.id.itsave);
        else optionsmenu = menu;
        return true;
    }
    
    @Override 
    public boolean onPrepareOptionsMenu(Menu menu) {
    	menu.findItem(R.id.itauto).setChecked(project.getaddnewevents());
    	menu.findItem(R.id.itdatalogging).setChecked(project.getdatalogging());
        return true;    	
    }
    	
    public boolean onOptionsItemSelected(MenuItem item) {
    	switch (item.getItemId()) {
            case android.R.id.home: {
            	finish();
                return true;
            }
            case R.id.itclear: {
            	AlertDialog.Builder alert = new AlertDialog.Builder(this);

            	alert.setTitle(R.string.deleteallevents);
            	alert.setMessage(R.string.prompt_confirm);
            	
            	alert.setNegativeButton(R.string.cancel, null);
            	alert.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
            	public void onClick(DialogInterface dialog, int whichButton) {
                	project.getevents().clear();
                	llevents.removeAllViews();
	            	}
            	});

            	AlertDialog dialog = alert.create();
            	dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
            	dialog.show();
            	return true;
            }
            case R.id.itadd: {
            	final ExchangeValues context = this;
            	
            	Resources res = getResources();
                String[] events_array = res.getStringArray(R.array.events);                 
                
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
            	builder.setTitle(R.string.addevent);
            	
            	int p = 0;
            	for (int i = 0; i < project.getevents().size(); i++) {
            		if (project.getevents().get(i).getname().equals("event" + p)) {
            			p++;
            			i = -1;
            		}
            	}
            	nextname = "event" + p;
            	
            	LinearLayout llroot = new LinearLayout(context);
            	View v = View.inflate(context, R.layout.entername, llroot);            	
            	builder.setView(llroot);
            	EditText et = (EditText) v.findViewById(R.id.etname);
            	
            	et.setText(nextname);
            	et.addTextChangedListener(new TextWatcher() {

					@Override
					public void afterTextChanged(Editable arg0) {}

					@Override
					public void beforeTextChanged(CharSequence s, int start,
							int count, int after) {}

					@Override
					public void onTextChanged(CharSequence s, int start,
							int before, int count) {
						nextname = s.toString();
						}
					});
            	
            	builder.setItems(events_array, new DialogInterface.OnClickListener() {
            	    public void onClick(DialogInterface dialog, int item) {  
            	    	switch (item) {
            	    	case 0: addevent(new ValueReceiver(nextname,context)); return;
            	    	case 1: addevent(new IntegerSender(nextname,context)); return;
            	    	case 2: addevent(new EventReceiver(nextname,context)); return;
            	    	case 3: addevent(new StringSender(nextname,context)); return;
            	    	case 4: addevent(new BooleanSender(nextname,context)); return;
            	    	case 5: addevent(new EventSender(nextname,context)); return;
            	    	case 6: addevent(new ColorReceiver(nextname,context)); return;
            	    	case 7: addevent(new ColorSender(nextname,context)); return;
            	    	case 8: addevent(new Joystick(nextname,context)); return;
            	    	default: return;
            	    	}            	    	
            	    }
            	});
            	AlertDialog alert = builder.create();
            	alert.show();
            	return true;
            }
            case R.id.itrequestsetup: {
            	send("requestsetup\n");
            	return true;
            }
            case R.id.itparse: {
            	AlertDialog.Builder alert = new AlertDialog.Builder(this);

            	alert.setTitle(R.string.parsestring);
            	alert.setMessage(R.string.prompt_message);

            	final EditText input = new EditText(this);
            	alert.setView(input);
            	input.setText(parsestring);
            	input.selectAll();
            	input.setInputType(InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
            	input.setSelectAllOnFocus(true);
            	
            	alert.setNegativeButton(R.string.cancel, null);
            	alert.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
            	public void onClick(DialogInterface dialog, int whichButton) {
            		parsestring = input.getText().toString();
	            	receiveEvent(parsestring);
	            	}
            	});

            	AlertDialog dialog = alert.create();
            	dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
            	dialog.show();
            	return true;
            }
            case R.id.itsave: {
            	if (project.getid() != -1) {
            		SharedPreferences settings = getSharedPreferences(MainActivity.PREFS_NAME, 0);
            	    SharedPreferences.Editor editor = settings.edit();
            		project.save(editor);
            		editor.commit();
            		Toast.makeText(this, R.string.projectsaved, Toast.LENGTH_SHORT).show();
            		return true;
            	}
            	AlertDialog.Builder alert = new AlertDialog.Builder(this);

            	alert.setTitle(R.string.saveproject);
            	alert.setMessage(R.string.prompt_name);

            	final EditText input = new EditText(this);
            	alert.setView(input);
            	input.setText(R.string.btproject);
            	input.selectAll();
            	input.setInputType(InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
            	input.setSelectAllOnFocus(true);            	
            	
            	final Activity activity = this;
            	alert.setNegativeButton(R.string.cancel, null);            	
            	alert.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
            	public void onClick(DialogInterface dialog, int whichButton) {
            		project.setname(input.getText().toString());
            		project.setid(MainActivity.getnewid());
            		project.setaddnewevents(false);
            		MainActivity.instance.addproject(project);
            		
            		SharedPreferences settings = getSharedPreferences(MainActivity.PREFS_NAME, 0);
            	    SharedPreferences.Editor editor = settings.edit();
            		project.save(editor);
            		editor.commit();
            		
            		MainActivity.standardproject = null;
            		if (optionsmenu != null)
            			optionsmenu.removeItem(R.id.itsave);
            		
            		activity.setTitle(project.getname());
            		Toast.makeText(activity, R.string.projectsaved, Toast.LENGTH_SHORT).show();            		
            	  	}
            	});
            	
            	AlertDialog dialog = alert.create();
            	dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
            	dialog.show();
            	return true;
            }
            case R.id.itauto: {
            	project.setaddnewevents(!project.getaddnewevents());
            	return true;
            }
            case R.id.itdatalogging:            	
            	project.switchdatalogging();
            	return true;
            case R.id.itfilename:
            	AlertDialog.Builder alert = new AlertDialog.Builder(this);

            	alert.setTitle(R.string.filename_title);
            	alert.setMessage(R.string.filename_prompt);

            	final EditText input = new EditText(this);
            	alert.setView(input);
            	input.setText(project.getfilename());
            	input.selectAll();
            	input.setInputType(InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
            	input.setSelectAllOnFocus(true);
            	
            	alert.setNegativeButton(R.string.cancel, null);
            	alert.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
            	public void onClick(DialogInterface dialog, int whichButton) {
            		project.setfilename(input.getText().toString());
            		SharedPreferences settings = getSharedPreferences(MainActivity.PREFS_NAME, 0);
            	    SharedPreferences.Editor editor = settings.edit();
            		project.save(editor);
            		editor.commit();
	            	}
            	});

            	AlertDialog dialog = alert.create();
            	dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
            	dialog.show();
            	return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    
    public void onPause() {
    	super.onPause();
    	if (project.issaved()) {
    		// Save
    		SharedPreferences settings = getSharedPreferences(MainActivity.PREFS_NAME, 0);
    	    SharedPreferences.Editor editor = settings.edit();
    		project.save(editor);
    		editor.commit();
    	}    	
    }
    
    public BTEvent getevent(String name) {
    	for (int i = 0; i < project.getevents().size(); i++) 
    		if (project.getevents().get(i).getname().equals(name))
    			return project.getevents().get(i);
    	return null;    	
    }
    
    public BTProject getproject() {
    	return project;
    }
}
