package com.marian.arduino;

public class BTduino extends android.app.Application {
	// TODO fonts/toasts
	// TODO handle corrupt messages
	// TODO lower API level (2.3 / API 8)
	// TODO change order
	// TODO btconsole
	
	// Features
		// TODO autoreconnect
		// TODO IR tool
		// Value Receiver
			// TODO custom borders?
		// Joystick
			// TODO change settings via bluetooth
			// TODO change fullscreen joystick layout (left/right)
			// TODO better accelerometer support	
	
}