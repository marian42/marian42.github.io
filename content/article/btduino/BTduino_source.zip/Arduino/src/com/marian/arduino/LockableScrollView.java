package com.marian.arduino;

import android.content.Context;
import android.view.MotionEvent;
import android.widget.ScrollView;

class LockableScrollView extends ScrollView {

	    public LockableScrollView(Context context) {
			super(context);
			mScrollable = true;
		}

		// true if we can scroll (not locked)
	    // false if we cannot scroll (locked)
	    private boolean mScrollable = true;

	    public void setScrollable(boolean scrollable) {
	        mScrollable = scrollable;
	    }
	    public boolean isScrollable() {
	        return mScrollable;
	    }
	    
	    @Override
	    public boolean onInterceptTouchEvent(MotionEvent ev) {
	    	if (!mScrollable) return false;
	        return super.onInterceptTouchEvent(ev);
	    }
	}
	