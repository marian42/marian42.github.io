package com.marian.arduino;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Color;
import android.os.Environment;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

public class ColorReceiver extends BTEvent {
	
	private int value;
	private boolean showtext = true;
	private boolean datalogging = false;
	private List<String> history;	
	
	private TextView tvname;
	private TextView tvvalue;
	private ImageButton ibsend;
	
	private static final int FORMAT_INT = 0;
	private static final int FORMAT_HEX = 1;
	private static final int FORMAT_HTML = 2;
	private static final int FORMAT_RGB = 3;
	
	private static final int SHOW_TEXT = 1005;
	private static final int SAVE = 1006;
	private static final int COPY = 1007;
	
	public ColorReceiver(String name, ExchangeValues uiactivity) {
		this.name = name;
		this.uiactivity = uiactivity;
		value = Color.BLACK;
		history = new ArrayList<String>();
	}
	
	public static boolean isvalid(String message) {
		if (getvalue(message).length() > 0)
			if (getvalue(message).charAt(0) == '#')
				return true;
		return getname(message).compareToIgnoreCase("registercolor") == 0;
	}
	
	@Override
	public boolean canhandle(String s_name, String s_value) {
		if (s_name.compareToIgnoreCase("registercolor") == 0 && s_value.compareToIgnoreCase(name) == 0)
			return true;
		if (s_name.compareToIgnoreCase(name) == 0) return true;
		return false;
	}

	@Override
	public void handle(String s_name, String s_value) {
		if (s_name.equals("registercolor") && s_value.equals(name))
			return;
		
		if (!s_name.equals(name)) return;
		try {
			value = ColorSender.stringtocolor(s_value);
			if (history.size() == 0 || !ColorSender.colortostring(value,FORMAT_HTML).equals(history.get(history.size()-1)))
				history.add(ColorSender.colortostring(value,FORMAT_HTML));
			updateview();
		} catch (Exception e) {return;}
		
		if (datalogging) try {
			String folder = Environment.getExternalStorageDirectory() + "/Bluetooth/";
			if (uiactivity.getproject().issaved()) folder += uiactivity.getproject().getname() + "/";
			Date now = new Date();
			@SuppressWarnings("deprecation")
			String filename = folder + Sample.clearfilename(name) + String.format("-%d-%02d-%02d.txt",now.getYear()-100,now.getMonth()+1,now.getDate());
    		
    		File dir = new File(folder);
			dir.mkdirs();
			
			File myFile = new File(filename);
			
			if (!myFile.exists()) myFile.createNewFile();
			
			FileWriter f = new FileWriter(myFile,true);
			f.append(now.getTime() + " " + s_value + "\n");
			f.close();
		} catch (Exception e) {e.printStackTrace();}
	}

	@Override
	public View createView(Context context) {
		view = new LinearLayout(context);
		
		LayoutInflater mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		mInflater.inflate(R.layout.colorsender, (LinearLayout) view, true);	
		
		tvname = (TextView) view.findViewById(R.id.tvname);
		tvvalue = (TextView) view.findViewById(R.id.tvvalue);
		ibsend = (ImageButton) view.findViewById(R.id.ibsend);
		
		tvname.setText(name);		
		
		ibsend.setVisibility(View.GONE);
		RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams)tvvalue.getLayoutParams();
		params.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);		
		tvvalue.setLayoutParams(params);
		
		tvvalue.setOnClickListener(new View.OnClickListener() {			
			@Override
			public void onClick(View v) {
				showtext = !showtext;
				updateview();
			}
		});
		return view;
	}

	@Override
	public void updateview() {
		uiactivity.runOnUiThread(new Runnable() {
			@Override
			public void run() {
				if (tvvalue != null)
					tvvalue.setBackgroundColor(value);
					if (!showtext) tvvalue.setText("");
					else {
						tvvalue.setText("r=" + Color.red(value) + ", g=" + Color.green(value) + ", b=" + Color.blue(value) + "\n" + ColorSender.colortostring(value,FORMAT_HTML));
						
						if ((Color.red(value) + Color.green(value) + Color.blue(value)) / 3 > 128)
							tvvalue.setTextColor(Color.BLACK);
						else tvvalue.setTextColor(Color.WHITE);
					}				
			}});
	}

	@Override
	public String getinfo() {
		return String.format(uiactivity.getString(R.string.about_colorreceiver),name,name);
	}
	
	public void onCreateContextMenu(ContextMenu menu) {
		menu.add(0, SHOW_TEXT, 0, uiactivity.getText(R.string.showtext));
		menu.findItem(SHOW_TEXT).setCheckable(true);
		menu.findItem(SHOW_TEXT).setChecked(showtext);
		menu.add(0, SAVE, 0, uiactivity.getText(R.string.log));
		menu.findItem(SAVE).setCheckable(true);
		menu.findItem(SAVE).setChecked(datalogging);
		menu.add(0, COPY, 0 , uiactivity.getText(R.string.copy));
	}
	
	@SuppressWarnings("deprecation") // clipboard
	public boolean onContextItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case SHOW_TEXT:
			showtext = !showtext;
			updateview();
        	return true;
		case SAVE:
			datalogging = !datalogging;			
    		return true;
		case COPY:
			String copytext = ColorSender.colortostring(value, FORMAT_HTML);
			if(android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.HONEYCOMB) {
			    android.text.ClipboardManager clipboard = (android.text.ClipboardManager) uiactivity.getSystemService(Context.CLIPBOARD_SERVICE);
			    clipboard.setText(copytext);
			} else {
			    android.content.ClipboardManager clipboard = (android.content.ClipboardManager) uiactivity.getSystemService(Context.CLIPBOARD_SERVICE);
			    android.content.ClipData clip = android.content.ClipData.newPlainText(name,copytext);
			            clipboard.setPrimaryClip(clip);
			}
			Toast.makeText(uiactivity, String.format(uiactivity.getString(R.string.toast_copied), copytext), Toast.LENGTH_SHORT).show();
			return true;
		default: return false;
		}
	}
	
	@Override
	public void save(Editor editor, String prefix) {
		editor.putString(prefix + "/type", "ColorReceiver");
		editor.putString(prefix + "/name", name);
		editor.putInt(prefix + "/value", value);
		editor.putBoolean(prefix + "/showtext", showtext);	
	}

	@Override
	public void load(SharedPreferences settings, String prefix) {
		value = settings.getInt(prefix + "/value", value);
		showtext = settings.getBoolean(prefix + "/showtext", showtext);	
	}
}
