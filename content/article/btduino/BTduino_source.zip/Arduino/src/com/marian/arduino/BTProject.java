package com.marian.arduino;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import android.content.SharedPreferences;
import android.util.Log;

public class BTProject {
	private final String DEFAULTFILENAME = "/Bluetooth/%project/%name.txt";
	
	private String name;
	private int id;
	private List<BTEvent> events;
	private boolean loaded;
	private boolean saved;
	private boolean datalogging;
	private String filename;
	private int counter;
	
	private boolean logged = true;
	
	private boolean addnewevents = true;
	
	private BlockEvents blocked;
	
	public BTProject(String name, int id) {
		this.name = name;
		this.id = id;
		loaded = false;
		saved = true;
	}
	
	public BTProject() {
		name = "";
		id = -1;
		events = new ArrayList<BTEvent>();
		loaded = true;
		saved = false;
		counter = 0;
		filename = DEFAULTFILENAME;
		datalogging = true;
	}
	
	public void save(SharedPreferences.Editor editor) {
		if (name.equals("") || id == -1 || !loaded) return;
		editor.putString(id + "/name", name);
		editor.putInt(id + "/events", events.size());
		for (int i = 0; i < events.size(); i++) {
			events.get(i).save(editor, id + "/" + i);
		}
		editor.putBoolean(id + "/autoadd", addnewevents);
		editor.putBoolean(id + "/datalogging", datalogging);
		editor.putString(id + "/filename", filename);
		editor.putInt(id + "/counter", counter);
		saved = true;
	}
	
	public void load(SharedPreferences settings, ExchangeValues uiactivity) {
		name = settings.getString(id + "/name", "");
		events = new ArrayList<BTEvent>();
		int size = settings.getInt(id + "/events", 0);
		for (int i = 0; i < size; i++) {
			BTEvent event = BTEvent.load(settings,id + "/" + i, uiactivity);
			if (event != null) {
				events.add(event);
				if (event instanceof BlockEvents)
					blocked = (BlockEvents) event;
			}
			else Log.e("Loading Event", "Error loading event");			
		}
		addnewevents = settings.getBoolean(id + "/autoadd", addnewevents);
		datalogging = settings.getBoolean(id + "/datalogging", true);
		filename = settings.getString(id + "/filename", DEFAULTFILENAME);
		counter = settings.getInt(id + "/counter", 0);
		loaded = true;
	}
	
	public String getfilename(String name) {
		String result = filename;
		result = result.replace("%name", name);
		result = result.replace("%project", this.name);
		result = result.replace("%c", String.valueOf(counter));
		
		Date now = new Date();
		// String filename = folder + Sample.clearfilename(name) + String.format("-%d-%02d-%02d.txt",now.getYear()-100,now.getMonth()+1,now.getDate());
		
		result = result.replace("%year", String.format("%02d", now.getYear()%100));
		result = result.replace("%month", String.format("%02d", now.getMonth()+1));
		result = result.replace("%day", String.format("%02d", now.getDate()));
		result = result.replace("%hour", String.format("%02d", now.getHours()));
		result = result.replace("%min", String.format("%02d", now.getMinutes()));
		result = result.replace("%sec", String.format("%02d", now.getSeconds()));
		
		result.replace("//", "/");
		if (result.charAt(0) != '/')
			result = '/' + result;
		return Sample.clearfilename(result);
	}
	
	public void add(BTEvent event) {
		events.add(event);
	}
	
	public void remove(BTEvent event) {
		events.remove(event);
	}
	
	public List<BTEvent> getevents() {
		return events;
	}
	
	public void setid(int id) {
		this.id = id;
	}
	
	public void setname(String name) {
		this.name = name;
	}
	
	public boolean isloaded() {
		return loaded;
	}
	
	public int getid() {
		return id;
	}
	
	public String getname() {
		return name;
	}
	
	public BlockEvents getblocked() {
		return blocked;
	}
	
	public void setblocked(BlockEvents be) {
		blocked = be;
	}
	
	public boolean issaved() {
		return saved;
	}
	
	public boolean getaddnewevents() {
		return addnewevents;
	}
	
	public void setaddnewevents(boolean b) {
		addnewevents = b;
	}
	
	public boolean getdatalogging() {
		return datalogging;
	}
	
	public void switchdatalogging() {
		datalogging = !datalogging;
		if (datalogging) logged = false;
		else {
			if (logged) counter++;
		}
	}
	
	public boolean getlogged() {
		return logged;
	}
	
	public String getfilename() {
		return filename;
	}
	
	public void setfilename(String s) {
		filename = s;
	}
	
	public void setlogged() {
		logged = true;
	}
}
