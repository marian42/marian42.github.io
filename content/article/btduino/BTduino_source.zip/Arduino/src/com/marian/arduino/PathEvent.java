package com.marian.arduino;

import java.io.File;
import java.util.List;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Environment;
import android.os.SystemClock;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

public class PathEvent extends BTEvent {
	private TextView tvname;
	private ImageButton ibplay;
	
	private String joystickname;
	private boolean playing;
	private List<Sample> path;
	private String filename;
	
	public PathEvent(String name, ExchangeValues uiactivity) {
		this.name = name;
		this.uiactivity = uiactivity;		
		playing = false;
		path = null;
		joystickname = name;
	}
	
	public PathEvent(String name, String joystickname, List<Sample> path, ExchangeValues uiactivity) {
		this.name = name;
		this.uiactivity = uiactivity;		
		playing = false;
		this.path = path;
		this.joystickname = joystickname;
		
		// Get filename
		filename = Environment.getExternalStorageDirectory() + "/Bluetooth/" + Sample.clearfilename(uiactivity.getproject().getname()) + "/path";
		int i = -1;
		File file;
		do {
			i++;
			file = new File(filename + i + ".txt");
		} while (file.exists());
		filename += i + ".txt";
		
		// Save
		Sample.savePath(path, filename);
	}
	
	public static boolean isvalid(String message) {
		 return false;
	}
	
	@Override
	public boolean canhandle(String s_name, String s_value) {
		return false;
	}

	@Override
	public void handle(String message) {
		
	}

	void send(double x, double y) {
		uiactivity.send(joystickname + ":" + ValueReceiver.trimTrailingZeros(x, 3) + "|" + ValueReceiver.trimTrailingZeros(y, 3) + "\n");
	}
	
	@Override
	public View createView(Context context) {
		view = new LinearLayout(context);
	
		LayoutInflater mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		mInflater.inflate(R.layout.path, (LinearLayout) view, true);
		
		tvname = (TextView) view.findViewById(R.id.tvname);
		ibplay = (ImageButton) view.findViewById(R.id.ibplay);
		
		tvname.setText(name);
		ibplay.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				if (!playing) {
					playing = true;
					Thread t = new Thread(new Runnable() {
						@Override
						public void run() {
							long s = SystemClock.elapsedRealtime();
							int p = 0;
							while (playing && path != null) {
								if (p < path.size()) {
									if (SystemClock.elapsedRealtime() >= s + path.get(p).t) {
										send(path.get(p).x,path.get(p).y);										
										p++;										
									}
									else try { synchronized (this) { wait(20);} } catch (InterruptedException e) { e.printStackTrace(); }									
								}
								else playing = false;
							}							
							
							send(0,0);
							
							ibplay.post(new Runnable() {
								@Override
								public void run() {
									ibplay.setImageResource(R.drawable.play);
								}});							
						}});
					t.start();
					ibplay.setImageResource(R.drawable.stop);
				}
				else {
					playing = false;
				}			
			}
		});
		
		return view;
	}

	@Override
	public void updateview() {
		
	}

	@Override
	public String getinfo() {
		return String.format(uiactivity.getString(R.string.about_pathevent), joystickname);
	}
	
	@Override
	public void save(Editor editor, String prefix) {
		editor.putString(prefix + "/type", "PathEvent");
		editor.putString(prefix + "/name", name);
		editor.putString(prefix + "/filename", filename);
	}

	@Override
	public void load(SharedPreferences settings, String prefix) {
		filename = settings.getString(prefix + "/filename", "");
		if (filename != "")
			path = Sample.loadPath(filename);
	}

}
