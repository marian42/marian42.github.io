package com.marian.arduino;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.Activity;
import android.os.Bundle;


public class BTActivity extends Activity {
	protected boolean connected = false;
	
	@SuppressLint("NewApi")
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		connect();
		
		ActionBar actionBar = getActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
	}
	
	public void connect() {
		if (MainActivity.mSerialService != null) {
			MainActivity.mSerialService.setUIActivity(this);
			connected = true;
		}
	}
	
	public void onReceive(String s) {		
		
	}
	
	public void send(String s) {
		if (MainActivity.mSerialService != null)
			MainActivity.mSerialService.write(s);
	}
}
