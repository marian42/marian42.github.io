package com.marian.arduino;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

public class BooleanSender extends BTEvent {	
	private boolean value;
	
	private TextView tvname;
	private Switch btnswitch;
	
	private boolean locked = false;

	public BooleanSender(String name, ExchangeValues uiactivity) {
		this.name = name;
		this.uiactivity = uiactivity;
		value = false;
	}
	
	public static boolean isvalid(String message) {
		 return message.startsWith("requestboolean:") || message.startsWith("requestbool:");
	}
	
	@Override
	public boolean canhandle(String s_name, String s_value) {
		String message = s_name + ":" + s_value;		
		return (message.compareToIgnoreCase("requestboolean:" + name) == 0) || (message.compareToIgnoreCase("requestbool:" + name) == 0) || (s_name.compareToIgnoreCase(name) == 0);
	}

	@Override
	public void handle(String s_name, String s_value) {
		if (s_name.compareToIgnoreCase("requestboolean") == 0 && s_value.compareToIgnoreCase(name) == 0) send();
		if (s_name.compareToIgnoreCase(name) != 0) return;		
		
		if (s_value.compareToIgnoreCase("true") == 0) value = true;
		if (s_value.compareToIgnoreCase("1") == 0) value = true;
		if (s_value.compareToIgnoreCase("HIGH") == 0) value = true;
		if (s_value.compareToIgnoreCase("false") == 0) value = false;
		if (s_value.compareToIgnoreCase("0") == 0) value = false;
		if (s_value.compareToIgnoreCase("LOW") == 0) value = false;
		locked = true;
		
		updateview();		
	}

	private void send() {
		uiactivity.send(name + ":" + (value ? "true" : "false")+"\n");
	}

	@Override
	public View createView(Context context) {
		view = new LinearLayout(context);
	
		LayoutInflater mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		mInflater.inflate(R.layout.booleansender, (LinearLayout) view, true);
		
		tvname = (TextView) view.findViewById(R.id.tvname);
		btnswitch = (Switch) view.findViewById(R.id.btnswitch);
		
		tvname.setText(name);
		btnswitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {			
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				value = isChecked;
				if (locked) {
					locked = false;
					return;
				}
				send();								
			}
		});
		
		return view;
	}

	@Override
	public void updateview() {
		if (view == null) {
			locked = false;
			return;			
		}
		btnswitch.post(new Runnable() { 
			@Override
			public void run() {
				btnswitch.setChecked(value);
			}
		});		
	}

	@Override
	public String getinfo() {
		return String.format(uiactivity.getString(R.string.about_booleansender), name, name, name);
	}

	@Override
	public void save(Editor editor, String prefix) {
		editor.putString(prefix + "/type", "BooleanSender");
		editor.putString(prefix + "/name", name);
		editor.putBoolean(prefix + "/value", value);		
	}

	@Override
	public void load(SharedPreferences settings, String prefix) {
		value = settings.getBoolean(prefix + "/value", value);		
	}

}
