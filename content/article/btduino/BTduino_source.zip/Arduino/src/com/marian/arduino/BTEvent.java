package com.marian.arduino;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;

public abstract class BTEvent {
	protected View view;
	protected String name;
	protected ExchangeValues uiactivity;
	
	private static final String error = "<error>--------";
	
	public BTEvent(ExchangeValues uiactivity, String name) {
		this.name = name;
		this.uiactivity = uiactivity;
	}
	
	public BTEvent() {
		name = "";
	}
	
	public String getname() {
		return name;
	}
	
	public boolean canhandle(String message) {
		if (message.indexOf(':') == -1) return false;
		String name = message.substring(0,message.indexOf(':'));
		String value = message.substring(message.indexOf(':')+1);
		return canhandle(name,value);
	}
	
	public abstract boolean canhandle(String s_name, String s_value);
	
	public static String getname(String message) {
		if (message.indexOf(':') == -1) return "";
		return message.substring(0,message.indexOf(':'));
	}
	
	public static String getvalue(String message) {
		if (message.indexOf(':') == -1) return "";
		return message.substring(message.indexOf(':')+1);
	}
	
	public void handle(String message) {
		if (message.indexOf(':') == -1) return;
		String name = message.substring(0,message.indexOf(':'));
		String value = message.substring(message.indexOf(':')+1);
		handle(name,value);
	}
	
	public void handle(String s_name, String s_value) {
	
	}
	
	public abstract View createView(Context context);
	
	public View getView() {
		return view;
	}
	
	public abstract void updateview();
	
	public void onCreateContextMenu(ContextMenu menu) {
		
	}
	
	public boolean onContextItemSelected(MenuItem item) {
		return false;
	}
	
	public abstract String getinfo();
	
	public void setuiactivity(ExchangeValues uiactivity) {
		this.uiactivity = uiactivity;
	}
	
	// Load and Save
	public abstract void save(SharedPreferences.Editor editor, String prefix);
	
	public abstract void load(SharedPreferences settings, String prefix);
	
	public static BTEvent load(SharedPreferences settings, String prefix, ExchangeValues uiactivity) {
		String name = settings.getString(prefix + "/name", error);
		if (name == error) return null;
		String type = settings.getString(prefix + "/type", error);
		if (type == error) return null;
		
		BTEvent event = null;
		if (type.equals("BlockEvents")) event = new BlockEvents(uiactivity);
		if (type.equals("BooleanSender")) event = new BooleanSender(name, uiactivity);
		if (type.equals("ColorReceiver")) event = new ColorReceiver(name, uiactivity);
		if (type.equals("ColorSender")) event = new ColorSender(name, uiactivity);
		if (type.equals("EventReceiver")) event = new EventReceiver(name, uiactivity);
		if (type.equals("EventSender")) event = new EventSender(name, uiactivity);
		if (type.equals("IntegerSender")) event = new IntegerSender(name, uiactivity);
		if (type.equals("Joystick")) event = new Joystick(name, uiactivity);
		if (type.equals("PathEvent")) event = new PathEvent(name, uiactivity);
		if (type.equals("StringSender")) event = new StringSender(name, uiactivity);
		if (type.equals("ValueReceiver")) event = new ValueReceiver(name, uiactivity);
		
		if (event == null) Log.e("Load event","Unknown type: " + type);
		
		event.load(settings, prefix);
		return event;
	}
}
