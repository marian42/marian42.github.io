package com.marian.arduino;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Bitmap.Config;
import android.graphics.Paint.Style;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.MotionEvent.PointerCoords;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;


public class FullscreenJoystick extends Activity 
	implements SensorEventListener{
	public static Joystick joystick;
	
	private static final int DYNAMICPOSITION = 33;
	private static final int ACCELEROMETER = 34;
	private static final int CALIBRATE = 35;
	
	private static final int PRE_LOCKED = 0;
	private static final int LOCKED = 1;
	private static final int UNLOCKED = 2;
	
	private int sensorlockedstate;
	private boolean positive_x;
	private boolean positive_y;
	private boolean x_thresh;
	private boolean y_thresh;
	
	private boolean portrait;
	private static boolean gsensor = false;
	private static boolean dynamicposition = false;
	
	private boolean calibrate = false;
	private boolean screentouched = false;
	
	private SensorManager mSensorManager;
    private Sensor mAccelerometer;
    private static double calibration_px = 0;
    private static double calibration_py = 6;
    private static double calibration_lx = 0;
    private static double calibration_ly = 7;

	private ImageView iv;
	private Bitmap bmp;
	private Canvas canvas;
	private Paint paint;
	private boolean ready;
	private float centerx;
	private float centery;
	private float rightcx;
	private float rightcy;
	private float leftcx;
	private float leftcy;
	private float rpad;
	
	private int leftpointer = -1;
	private int rightpointer = -1;
	
	private double x;
	private double y;
	
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState); 
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, 
                                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if (joystick == null) {
        	this.runOnUiThread(new Runnable() {
				@Override
				public void run() {
					finish();					
				}});
        	return;
        }
        
        joystick.fullscreen = this;        
        
        x = joystick.getx();
        y = joystick.gety();
        
        iv = new ImageView(this);
        this.setContentView(iv);
        
        iv.setOnTouchListener(new View.OnTouchListener() {			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				if (gsensor) {
					if (event.getAction() == MotionEvent.ACTION_DOWN) {
						screentouched = true;
						joystick.fingerdown();
						joystick.set(0, 0);
						joystick.send();
						draw();
					}
					if (event.getAction() == MotionEvent.ACTION_UP) {
						screentouched = false;
						joystick.fingerdown();						
						draw();
					}
					return true;
				}
				
				if (portrait) {
					if (!(event.getAction() == MotionEvent.ACTION_DOWN || event.getAction() == MotionEvent.ACTION_MOVE || event.getAction() == MotionEvent.ACTION_UP))
						return true;
					if (joystick.isplaying()) return true;
					
					if (event.getAction() == MotionEvent.ACTION_DOWN) {
						joystick.fingerdown();
						if (dynamicposition) {
							centerx = event.getX();
							centery = event.getY();
						}					
						else {
							standardposition();
						}
					}			
					
					joystick.set((event.getX() - centerx) / rpad,(event.getY() - centery) / rpad);
					
					if (event.getAction() == MotionEvent.ACTION_UP)
						joystick.fingerup();
					
				}
				else {	
					x = joystick.getx();
					y = joystick.gety();
					
					if (event.getActionMasked() == MotionEvent.ACTION_DOWN || event.getActionMasked() == MotionEvent.ACTION_POINTER_DOWN) {
						PointerCoords myPointerCoords = new PointerCoords();
						event.getPointerCoords(event.getActionIndex(), myPointerCoords);
						if (myPointerCoords.x < bmp.getWidth() / 2) {
							if (dynamicposition) {
								leftcx = myPointerCoords.x;
								leftcy = myPointerCoords.y;
							}
							else standardposition();
							leftpointer = event.getPointerId(event.getActionIndex());							
							joystick.set((myPointerCoords.x - leftcx) / rpad,joystick.gety());
						}
						else {
							if (dynamicposition) {
								rightcx = myPointerCoords.x;
								rightcy = myPointerCoords.y;
							}
							else standardposition();
							rightpointer = event.getPointerId(event.getActionIndex());
							joystick.set(joystick.getx(),(myPointerCoords.y - rightcy) / rpad);
						}
						joystick.fingerdown();
					}
					else {
						for (int i = 0; i < event.getPointerCount(); i++) {
							if (event.getPointerId(i) == leftpointer) {
								PointerCoords myPointerCoords = new PointerCoords();
								event.getPointerCoords(i, myPointerCoords);
								x = (myPointerCoords.x - leftcx) / rpad;
							}
							if (event.getPointerId(i) == rightpointer) {
								PointerCoords myPointerCoords = new PointerCoords();
								event.getPointerCoords(i, myPointerCoords);
								y = (myPointerCoords.y - rightcy) / rpad;
							}	
						}
						
						if (event.getAction() == MotionEvent.ACTION_UP || event.getActionMasked() == MotionEvent.ACTION_POINTER_UP) {
							if (leftpointer == event.getPointerId(event.getActionIndex())) {
								leftpointer = -1;
								if (joystick.getautocenter())
									x = 0;
							}
							if (rightpointer == event.getPointerId(event.getActionIndex())) {
								rightpointer = -1;
								if (joystick.getautocenter())
									y = 0;
							}
							joystick.fingerdown(); // fingerup without autocenter
						}						
					}
					joystick.set(x, y);
				}
				draw();
				joystick.send();
				return true;
			}
		});
        
        ready = false;
        draw();
    }
	
	private void setuppainting() {		
		Config conf = Bitmap.Config.ARGB_8888; 
		if (iv.getWidth() == 0) return;
		bmp = Bitmap.createBitmap(iv.getWidth(), iv.getHeight(), conf);
        canvas = new Canvas(bmp);
        
		paint = new Paint();
		paint.setAntiAlias(true);
        
		portrait = iv.getWidth() < iv.getHeight();
		
		ready = true;
		standardposition();
	}
	
	private void standardposition() {
		if (!ready) setuppainting();
		if (portrait) {			
			centerx = bmp.getWidth() / 2;
			centery = (float) (bmp.getHeight() - centerx * 1.1);		
			rpad = (int) (centerx * 0.5);			
		}
		else {
			rpad = (float) (bmp.getHeight() * 0.25);
			
			leftcx = (float) (rpad * 1.2);
			rightcx = (float) (bmp.getWidth() - rpad * 1.2);
			leftcy = (float) (bmp.getHeight() - rpad * 1.2);
			rightcy = leftcy;
		}
	}
	
	void draw() {
		iv.post(new Runnable() {
			@Override
			public void run() {
				if (!ready) setuppainting();
				if (!ready) return;
				paint.setColor(Color.BLACK);
				
				paint.setStyle(Style.FILL);
				canvas.drawRect(0, 0, bmp.getWidth(), bmp.getHeight(), paint);
				
				x = joystick.getx();
				y = joystick.gety();
				
				if (portrait) {					
					int rstick = (int) (rpad * 0.5);
					
					paint.setColor(Color.GRAY);
					paint.setStyle(Style.STROKE);
					paint.setStrokeWidth(4);
					if (!joystick.issquare())
						canvas.drawCircle(centerx, centery, rpad, paint);
					else canvas.drawRect(centerx - rpad, centery - rpad, centerx + rpad, centery + rpad, paint);
					
					paint.setColor(Color.WHITE);
					if (joystick.isrecording()) paint.setColor(Color.RED);
					if (joystick.isplaying()) paint.setColor(Color.BLUE);
					canvas.drawCircle((float)(centerx + x * rpad), (float) (centery + y * rpad), rstick, paint);	
					
					if (screentouched && gsensor) {
						paint.setColor(Color.RED);
						canvas.drawCircle((float)(centerx), (float) (centery), rstick, paint);						
					}
				}
				else {
					float rail = (float) 0.15;
					paint.setColor(Color.GRAY);
					paint.setStyle(Style.STROKE);					
					paint.setStrokeWidth(4);
					
					// right
					canvas.drawRect((float) (rightcx - rpad * rail), rightcy - rpad, rightcx + rpad * rail, rightcy + rpad, paint);					
					
					// left
					canvas.drawRect((float) (leftcx - rpad), leftcy - rpad * rail, leftcx + rpad, leftcy + rpad * rail, paint);
					
					paint.setColor(Color.WHITE);
					if (joystick.isrecording()) paint.setColor(Color.RED);
					if (joystick.isplaying()) paint.setColor(Color.BLUE);
					canvas.drawRect((float)(leftcx + rpad * x - rpad * rail), (float)(leftcy - rpad * rail * 3), (float) (leftcx + rpad * x + rpad * rail), leftcy + rpad * rail * 3, paint);
					canvas.drawRect((float)(rightcx - rpad * rail * 3), (float)(rightcy + rpad * y - rpad * rail), rightcx + rpad * rail * 3, (float) (rightcy + rpad * y + rpad * rail), paint);
				
					if (screentouched && gsensor) {
						paint.setColor(Color.RED);
						canvas.drawRect((float)(leftcx - rpad * rail), (float)(leftcy - rpad * rail * 3), (float) (leftcx + rpad * rail), leftcy + rpad * rail * 3, paint);
						canvas.drawRect((float)(rightcx - rpad * rail * 3), (float)(rightcy - rpad * rail), rightcx + rpad * rail * 3, (float) (rightcy + rpad * rail), paint);			
					}
				}
				
				if (gsensor) {
					String s = getString(R.string.hint_center);
					if (sensorlockedstate == LOCKED)
						s = getString(R.string.hint_unlock);
					paint.setTextAlign(Paint.Align.CENTER);
					paint.setTextSize(20);
					paint.setColor(Color.GRAY);
					paint.setStyle(Paint.Style.FILL);
					canvas.drawText(s, bmp.getWidth() / 2, 50, paint);
				}
				iv.setImageBitmap(bmp);
			}
		});
	}
	
	public boolean onPrepareOptionsMenu(Menu menu) {
		menu.clear();
		menu.add(0, DYNAMICPOSITION, 0, R.string.dynamicposition);
		menu.findItem(DYNAMICPOSITION).setCheckable(true);
		menu.findItem(DYNAMICPOSITION).setChecked(dynamicposition);
		menu.add(0, ACCELEROMETER, 0, R.string.accelerometer);
		menu.findItem(ACCELEROMETER).setCheckable(true);
		menu.findItem(ACCELEROMETER).setChecked(gsensor);
		if (gsensor) menu.add(0, CALIBRATE, 0, R.string.calibrate);
		return true;
	}
	
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case DYNAMICPOSITION: dynamicposition = !dynamicposition;
			return true;
		case ACCELEROMETER: gsensor = !gsensor;
			if (gsensor) startsensor();
			else stopsensor();
			draw();
			return true;
		case CALIBRATE: calibrate = true;
			return true;
		}
		return false;		
	}
	
	public void onPause() {
		super.onPause();
		joystick.fullscreen = null;
		joystick.draw();
		if (gsensor) stopsensor();
	}
	
	public void onResume() {
		super.onResume();
		joystick.fullscreen = this;
		if (gsensor) startsensor();
	}

	@Override
	public void onAccuracyChanged(Sensor sensor, int accuracy) {
		
	}
	
	private void startsensor() {		
		if(getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT)
		    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
		if(getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE)
		    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);		
		mSensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);
        mAccelerometer = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        mSensorManager.registerListener(this, mAccelerometer, SensorManager.SENSOR_DELAY_GAME);
        
        sensorlockedstate = PRE_LOCKED;
        iv.post(new Runnable() {
			@Override
			public void run() {
				standardposition();				
			}        	
        });
	}

	private void stopsensor() {
		mSensorManager.unregisterListener(this);
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
		if (joystick.getautocenter()) joystick.set(0, 0);
	}
	
	@Override
	public void onSensorChanged(SensorEvent event) {
		if (!gsensor) {
			stopsensor();
			return;
		}
		if (portrait) {
			joystick.set(-(event.values[0] - calibration_px) / 5.0, (event.values[1]  - calibration_py) / 5.0);
			if (calibrate) {
				calibration_px = event.values[0];
				calibration_py = event.values[1];
				calibrate = false;
			}
		}
		else {
			joystick.set((event.values[1] - calibration_lx) / 5.0, (event.values[0] - calibration_ly) / 4.0);
			if (calibrate) {
				calibration_lx = event.values[1];
				calibration_ly = event.values[0];
				calibrate = false;
			}
		}
		
		if (sensorlockedstate == PRE_LOCKED) {
			positive_x = joystick.getx() > 0;
			positive_y = joystick.gety() > 0;
			x_thresh = false;
			y_thresh = false;
			sensorlockedstate++;
		}
		else if (sensorlockedstate == LOCKED) {
			if (positive_x != joystick.getx() > 0) x_thresh = true;
			if (positive_y != joystick.gety() > 0) y_thresh = true;
			if (x_thresh && y_thresh) sensorlockedstate++;
		}
		
		draw();
		if (!screentouched && sensorlockedstate == UNLOCKED)
			joystick.send();
	}
}