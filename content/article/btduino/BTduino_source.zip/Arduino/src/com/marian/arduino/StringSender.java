package com.marian.arduino;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class StringSender extends BTEvent {
	private String value;
	
	private TextView tvname;
	private EditText etvalue;
	private ImageButton ibsend;
	
	public StringSender(String name, ExchangeValues uiactivity) {
		this.name = name;
		this.uiactivity = uiactivity;
		value = "";		
	}
	
	public static boolean isvalid(String message) {
		return message.startsWith("requeststring:");
	}
	
	@Override
	public boolean canhandle(String s_name, String s_value) {		
		return (s_name.compareToIgnoreCase(name) == 0);
	}

	@Override
	public void handle(String s_name, String s_value) {
		if (s_name.compareToIgnoreCase("requeststring") == 0 && s_value.compareToIgnoreCase(name) == 0) { send(); return; }
		
		if (s_name.compareToIgnoreCase(name) != 0) return;
		try {
			value = s_value;
			updateview();			
		} catch (Exception e) {return;}
	}	
	
	private void send() {
		uiactivity.send(name + ":" + value+"\n");
	}

	@Override
	public View createView(Context context) {
		view = new LinearLayout(context);
		
		LayoutInflater mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		mInflater.inflate(R.layout.stringsender, (LinearLayout) view, true);	
		
		tvname = (TextView) view.findViewById(R.id.tvname);
		etvalue = (EditText) view.findViewById(R.id.etvalue);
		ibsend = (ImageButton) view.findViewById(R.id.ibsend);
		
		tvname.setText(name);		
		
		
		
		etvalue.setImeActionLabel(uiactivity.getString(R.string.send), KeyEvent.KEYCODE_ENTER);
		etvalue.setOnEditorActionListener(new TextView.OnEditorActionListener() {			
			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				if (actionId == KeyEvent.KEYCODE_ENTER) {
					try {
						value = etvalue.getText().toString();
						etvalue.selectAll();
						send();
					}
					catch (Exception e) {
						Toast.makeText(uiactivity, R.string.value_invalid, Toast.LENGTH_SHORT).show();
					}
					return true;
				}
				return false;
			}
		});
		
		ibsend.setOnClickListener(new View.OnClickListener() {			
			@Override
			public void onClick(View v) {				
				value = etvalue.getText().toString();
				etvalue.selectAll();
				send();
			}
		});
		return view;
	}

	@Override
	public void updateview() {
		if (view == null) return;
		uiactivity.runOnUiThread(new Runnable() {
			@Override
			public void run() {
				etvalue.setText(value);
			}});		
	}

	@Override
	public String getinfo() {
		return String.format(uiactivity.getString(R.string.about_stringsender), name, name);
	}
	
	@Override
	public void save(Editor editor, String prefix) {
		editor.putString(prefix + "/type", "StringSender");
		editor.putString(prefix + "/name", name);
		editor.putString(prefix + "/value", value);
	}

	@Override
	public void load(SharedPreferences settings, String prefix) {
		value = settings.getString(prefix + "/value", value);		
	}
}
