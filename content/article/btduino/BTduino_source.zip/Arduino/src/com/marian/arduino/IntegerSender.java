package com.marian.arduino;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class IntegerSender extends BTEvent {
	private double value;
	private double min;
	private double max;
	
	private TextView tvname;
	private EditText etvalue;
	private ImageButton ibsend;
	private ImageButton ibslider;
	private SeekBar sbslider;
	private Button btnmin;
	private Button btnmax;
	private RelativeLayout rlslider;

	private boolean showslider;
	private boolean blockslider;
	
	private long last = 0;
	private final int cooldown = 60;
	private boolean skipped = false;
	private boolean skipthreadrunning = false;
	
	public IntegerSender(String name, ExchangeValues uiactivity) {
		this.name = name;
		this.uiactivity = uiactivity;
		value = 0;
		showslider = false;
		min = 0;
		max = 100;
		blockslider = false;
	}
	
	public static boolean isvalid(String message) {
		return message.startsWith("requestint:") || message.startsWith("requestinteger:");
	}
	
	@Override
	public boolean canhandle(String s_name, String s_value) {
		String message = s_name + ":" + s_value;
		return message.compareToIgnoreCase("requestint:" + name) == 0 || message.compareToIgnoreCase("requestinteger:" + name) == 0 || s_name.compareToIgnoreCase(name) == 0 || s_name.compareToIgnoreCase("setmin" + name) == 0|| s_name.compareToIgnoreCase("setmax" + name) == 0;
	}

	@Override
	public void handle(String s_name, String s_value) {
		String message = s_name + ":" + s_value;
		if (message.compareToIgnoreCase("requestint:" + name) == 0 || message.compareToIgnoreCase("requestinteger:" + name) == 0) {
			send();
			return;
		}
		try {
			if (s_name.compareToIgnoreCase(name) == 0) {
				value = Double.valueOf(s_value);
				updateview();
				}
			if (s_name.compareToIgnoreCase("setmin" + name) == 0) {
				min = Double.valueOf(s_value);
				if (max < min) {
					double c = max;
					max = min;
					min = c;
				}
				updateview();
			}
			if (s_name.compareToIgnoreCase("setmax" + name) == 0) {
				max = Double.valueOf(s_value);
				if (max < min) {
					double c = max;
					max = min;
					min = c;
				}
				updateview();
			}
		} catch (Exception e) {return;}
		
		send();
	}	
	
	void send() {
		boolean skip = false;
		if (SystemClock.uptimeMillis() - last < cooldown) {
			skip = true;
			skipped = true;
			if (!skipthreadrunning) {
				skipthreadrunning = true;
				Thread skipthread = new Thread(new Runnable() {
					@Override
					public void run() {
						while (last + 5000 > SystemClock.uptimeMillis()) {
							if (skipped && last + cooldown < SystemClock.uptimeMillis()) {
								send_helper();								
							}
							try {
								synchronized (this) {
									this.wait((long) (cooldown * 1.5));
								}										
							} catch (InterruptedException e) {						
								e.printStackTrace();
							}
						}								
						skipthreadrunning = false;						
					}});
				skipthread.start();
			}
		}
		if (!skip) send_helper();	
	}
	
	private void send_helper() {
		uiactivity.send(name + ":" + ValueReceiver.trimTrailingZeros(value, 4)+"\n");
		last = SystemClock.uptimeMillis();
		skipped = false;
	}

	@Override
	public View createView(Context context) {
		view = new LinearLayout(context);
		
		LayoutInflater mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		mInflater.inflate(R.layout.integersender, (LinearLayout) view, true);	
		
		tvname = (TextView) view.findViewById(R.id.tvname);
		etvalue = (EditText) view.findViewById(R.id.itvalue);
		btnmin = (Button) view.findViewById(R.id.btnmin);
		btnmax = (Button) view.findViewById(R.id.btnmax);
		ibsend = (ImageButton) view.findViewById(R.id.ibsend);
		ibslider = (ImageButton) view.findViewById(R.id.ibshowslider);
		rlslider = (RelativeLayout) view.findViewById(R.id.rlslider);
		sbslider = (SeekBar) view.findViewById(R.id.sbslider);
		
		rlslider.setVisibility(showslider ? View.VISIBLE : View.GONE);
		
		tvname.setText(name);		
		
		btnmin.setOnClickListener(new View.OnClickListener() {			
			@Override
			public void onClick(View v) {
				try {					
					min = Double.valueOf(etvalue.getText().toString());
					if (max < min) {
						double a = max;
						max = min;
						min = a;
					}
					updateview();
				}
				catch (Exception e) {
					e.printStackTrace();
					Toast.makeText(uiactivity, R.string.value_invalid, Toast.LENGTH_SHORT).show();
					
				}
			}
		});
		
		btnmax.setOnClickListener(new View.OnClickListener() {			
			@Override
			public void onClick(View v) {
				try {
					max = Double.valueOf(etvalue.getText().toString());
					if (max < min) {
						double a = max;
						max = min;
						min = a;
					}
					updateview();
				}
				catch (Exception e) {
					Toast.makeText(uiactivity, R.string.value_invalid, Toast.LENGTH_SHORT).show();
				}	
			}
		});		
		
		etvalue.setImeActionLabel(uiactivity.getString(R.string.send), KeyEvent.KEYCODE_ENTER);
		etvalue.setOnEditorActionListener(new TextView.OnEditorActionListener() {			
			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				if (actionId == KeyEvent.KEYCODE_ENTER) {
					try {
						value = Double.valueOf(etvalue.getText().toString());
						send();
						updateview();
					}
					catch (Exception e) {
						Toast.makeText(uiactivity, R.string.value_invalid, Toast.LENGTH_SHORT).show();
					}
					return true;
				}
				return false;
			}
		});
		
		ibslider.setOnClickListener(new View.OnClickListener() {			
			@Override
			public void onClick(View v) {
				showslider = !showslider;
				rlslider.setVisibility(showslider ? View.VISIBLE : View.GONE);
				updateview();
			}
		});
		
		ibsend.setOnClickListener(new View.OnClickListener() {			
			@Override
			public void onClick(View v) {
				try {
					value = Double.valueOf(etvalue.getText().toString());
					send();
					updateview();
				}
				catch (Exception e) {
					Toast.makeText(uiactivity, R.string.value_invalid, Toast.LENGTH_SHORT).show();
				}		
			}
		});
		
		sbslider.setMax(1000);
		sbslider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {			
			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {
				
			}			
			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {
				this.onProgressChanged(seekBar, seekBar.getProgress(), true);
				
			}			
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress,
					boolean fromUser) {
				if (blockslider) {
					blockslider = false;
					return;
				}
				value = min + (max - min) * progress / sbslider.getMax();
				if (max - min > 10) value = (int)value;
				etvalue.setText(ValueReceiver.trimTrailingZeros(value, 3));
				send();
			}
		});
		
		return view;
	}

	@Override
	public void updateview() {
		if (view == null) return;
		uiactivity.runOnUiThread(new Runnable() {
			@Override
			public void run() {
				blockslider = true;
				if (value >= min && value <= max) {
					sbslider.setProgress((int) (1.0 * sbslider.getMax() * (value - min) / (max - min)));
				}
				else {
					if (value < min) sbslider.setProgress(0);
					if (value > max) sbslider.setProgress(sbslider.getMax());
				}
				if (etvalue != null) etvalue.setText(ValueReceiver.trimTrailingZeros(value, 3));
				if (btnmin != null) btnmin.setText(ValueReceiver.trimTrailingZeros(min, 3));
				if (btnmax != null) btnmax.setText(ValueReceiver.trimTrailingZeros(max, 3));
			}			
		});
	}

	@Override
	public String getinfo() {
		return String.format(uiactivity.getString(R.string.about_integersender), name, name);
	}

	@Override
	public void save(Editor editor, String prefix) {
		editor.putString(prefix + "/type", "IntegerSender");
		editor.putString(prefix + "/name", name);
		editor.putFloat(prefix + "/value", (float) value);
		editor.putFloat(prefix + "/min", (float) min);
		editor.putFloat(prefix + "/max", (float) max);
		editor.putBoolean(prefix + "/showslider", showslider);
	}

	@Override
	public void load(SharedPreferences settings, String prefix) {
		value = settings.getFloat(prefix + "/value", (float) value);
		min = settings.getFloat(prefix + "/min", (float) min);
		max = settings.getFloat(prefix + "/max", (float) max);
		showslider = settings.getBoolean(prefix + "/showslider", showslider);		
	}
	
}
