package com.marian.arduino;

import java.util.Locale;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Color;
import android.text.InputType;
import android.util.Log;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import net.margaritov.preference.colorpicker.ColorPickerDialog;

public class ColorSender extends BTEvent
	implements	
	ColorPickerDialog.OnColorChangedListener {
	
	private int value;
	private int format = FORMAT_INT;
	
	private TextView tvname;
	private TextView tvvalue;
	private ImageButton ibsend;
	
	private static final int FORMAT_INT = 0;
	private static final int FORMAT_HEX = 1;
	private static final int FORMAT_HTML = 2;
	private static final int FORMAT_RGB = 3;
	
	private static final int CHANGE_FORMAT = 1003;
	private static final int INPUT_COLOR = 1004;
	
	public ColorSender(String name, ExchangeValues uiactivity) {
		this.name = name;
		this.uiactivity = uiactivity;
		value = Color.BLACK;
	}
	
	public static boolean isvalid(String message) {
		return message.startsWith("requestcolor:");
	}
	
	@Override
	public boolean canhandle(String s_name, String s_value) {
		if (s_name.compareToIgnoreCase(name) == 0) return true;
		if (s_name.compareToIgnoreCase("requestcolor") == 0 && s_value.compareToIgnoreCase(name) == 0) return true;
		return false;
	}

	public static int stringtocolor(String s) {
		if (s.charAt(0) == '#')
			return Integer.decode("0x" + s.substring(1)) | 0xFF000000;
		return Integer.parseInt(s) | 0xFF000000;
	}
	
	@Override
	public void handle(String s_name, String s_value) {
		if (s_name.equals("requestcolor") && s_value.equals(name)) { send(); return; }
		
		if (!s_name.equals(name)) return;
		try {
			value = stringtocolor(s_value);
			updateview();
		} catch (Exception e) {return;}
	}
	
	public static String colortostring(int color, int format) {
		String v = "";
		switch (format) {
			case FORMAT_INT:  v = String.valueOf(color & 0xFFFFFF); 
							  break;
			case FORMAT_HTML: v = "#";
			case FORMAT_HEX:  v = v + (Color.red(color) < 16 ? "0" : "") + Integer.toHexString(Color.red(color)) + (Color.green(color) < 16 ? "0" : "") + Integer.toHexString(Color.green(color)) + (Color.blue(color) < 16 ? "0" : "") + Integer.toHexString(Color.blue(color)); 
							  v = v.toUpperCase(Locale.US);
							  break;
			case FORMAT_RGB:  v = (Color.red(color) < 100 ? "0" : "") + (Color.red(color) < 10 ? "0" : "") + String.valueOf(Color.red(color)) + "," + (Color.green(color) < 100 ? "0" : "") + (Color.green(color) < 10 ? "0" : "") + String.valueOf(Color.green(color)) + "," + (Color.blue(color) < 100 ? "0" : "") + (Color.blue(color) < 10 ? "0" : "") + String.valueOf(Color.blue(color));
							  break;
		}
		return v;
	}
	
	private void send() {
		String v = colortostring(value,format);
		uiactivity.send(name + ":" + v +"\n");
	}

	@Override
	public View createView(Context context) {
		view = new LinearLayout(context);
		
		LayoutInflater mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		mInflater.inflate(R.layout.colorsender, (LinearLayout) view, true);	
		
		tvname = (TextView) view.findViewById(R.id.tvname);
		tvvalue = (TextView) view.findViewById(R.id.tvvalue);
		ibsend = (ImageButton) view.findViewById(R.id.ibsend);
		
		tvname.setText(name);		
		
		ibsend.setOnClickListener(new View.OnClickListener() {			
			@Override
			public void onClick(View v) {				
				send();
			}
		});
		
		final ColorSender oncolorchangedlistener = this;
		tvvalue.setOnClickListener(new View.OnClickListener() {			
			@Override
			public void onClick(View v) {
				ColorPickerDialog cd = new ColorPickerDialog(uiactivity, value);
				cd.setTitle(uiactivity.getString(R.string.sendcolor));
				cd.setOnColorChangedListener(oncolorchangedlistener);
				cd.show();
			}
		});
		return view;
	}

	@Override
	public void updateview() {
		uiactivity.runOnUiThread(new Runnable() {
			@Override
			public void run() {
				if (tvvalue != null)
					tvvalue.setBackgroundColor(value);
					if (format == FORMAT_INT) 
						tvvalue.setText(colortostring(value,format) + "\n" + colortostring(value,FORMAT_HTML));
					else tvvalue.setText(colortostring(value,format));
					if ((Color.red(value) + Color.green(value) + Color.blue(value)) / 3 > 128)
						tvvalue.setTextColor(Color.BLACK);
					else tvvalue.setTextColor(Color.WHITE);
			}});
	}

	@Override
	public String getinfo() {
		return String.format(uiactivity.getString(R.string.about_colorsender), name, name);
	}
	
	public void onCreateContextMenu(ContextMenu menu) {
		menu.add(0, CHANGE_FORMAT, 0, uiactivity.getString(R.string.format));
		menu.add(0, INPUT_COLOR, 0, uiactivity.getString(R.string.prompt_color));
	}
	
	public boolean onContextItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case CHANGE_FORMAT:
			AlertDialog.Builder builder = new AlertDialog.Builder(uiactivity);
        	builder.setTitle(uiactivity.getString(R.string.changeformat));
        	
        	String formats[] = new String[4];
        	formats[FORMAT_INT] = uiactivity.getString(R.string.format_int) + " (" + colortostring(value,FORMAT_INT) + ")";  
        	formats[FORMAT_HEX] = uiactivity.getString(R.string.format_hex) + " (" + colortostring(value,FORMAT_HEX) + ")";  
        	formats[FORMAT_HTML] = uiactivity.getString(R.string.format_html) + " (" + colortostring(value,FORMAT_HTML) + ")";  
        	formats[FORMAT_RGB] = uiactivity.getString(R.string.format_rgb) + " (" + colortostring(value,FORMAT_RGB) + ")";  
        	
        	builder.setItems(formats, new DialogInterface.OnClickListener() {
        	    public void onClick(DialogInterface dialog, int item) {  
        	    	format = item;
        	    	updateview();        	    	           	    	
        	    }
        	});
        	AlertDialog alert = builder.create();
        	alert.show();
        	return true;	
		case INPUT_COLOR:
			AlertDialog.Builder alert1 = new AlertDialog.Builder(uiactivity);

        	alert1.setTitle(uiactivity.getString(R.string.prompt_color));
        	alert1.setMessage(uiactivity.getString(R.string.prompt_hex));

        	final EditText input = new EditText(uiactivity);
        	alert1.setView(input);
        	input.setText(colortostring(value,FORMAT_HTML));
        	input.selectAll();
        	input.setInputType(InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        	input.setSelectAllOnFocus(true);
        	
        	
        	alert1.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
	        	public void onClick(DialogInterface dialog, int whichButton) {
		        	try {
		        		value = stringtocolor(input.getText().toString());
		        		updateview();
		        	} catch (Exception e) {Toast.makeText(uiactivity, uiactivity.getString(R.string.value_invalid),Toast.LENGTH_SHORT).show(); }
		        }
	        });

        	AlertDialog dialog = alert1.create();
        	dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        	dialog.show();
        	return true;			
		default: return false;
		}
	}
	

	@Override
	public void onColorChanged(int color) {
		value = color;
		updateview();
		send();
	}
	
	@Override
	public void save(Editor editor, String prefix) {
		editor.putString(prefix + "/type", "ColorSender");
		editor.putString(prefix + "/name", name);
		editor.putInt(prefix + "/value", value);
		editor.putInt(prefix + "/format", format);	
	}

	@Override
	public void load(SharedPreferences settings, String prefix) {
		value = settings.getInt(prefix + "/value", value);
		format = settings.getInt(prefix + "/format", format);		
	}

}
