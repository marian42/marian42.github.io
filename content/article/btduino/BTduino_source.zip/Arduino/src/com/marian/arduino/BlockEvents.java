package com.marian.arduino;

import java.util.ArrayList;
import java.util.List;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class BlockEvents extends BTEvent {
	private final int UNBLOCKALL = 47;
	
	private List<BTEvent> block;
	private int counter;
	
	private TextView tvname;
	private ImageButton ibunblock;

	public BlockEvents(ExchangeValues uiactivity) {
		this.uiactivity = uiactivity;
		this.name = uiactivity.getString(R.string.block);
		block = new ArrayList<BTEvent>();
		counter = 0;
	}
	
	@Override
	public boolean canhandle(String s_name, String s_value) {
		for (int i = 0; i < block.size(); i++)
			if (block.get(i).canhandle(s_name,s_value)) return true;
		return false;
	}

	@Override
	public void handle(String message) {
		counter++;
	}

	@Override
	public View createView(Context context) {
		view = new LinearLayout(context);
		
		LayoutInflater mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		mInflater.inflate(R.layout.blockevents, (LinearLayout) view, true);
		
		tvname = (TextView) view.findViewById(R.id.tvname);
		ibunblock = (ImageButton) view.findViewById(R.id.ibunblock);
		
		tvname.setText(name + " (" + block.size() + ")");
		ibunblock.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				if (block.size() == 0) {
					Toast.makeText(uiactivity,uiactivity.getString(R.string.block_nothing), Toast.LENGTH_SHORT).show();
					return;
				}
				
				AlertDialog.Builder builder = new AlertDialog.Builder(uiactivity);
            	builder.setTitle(R.string.unblock);
            	builder.setIcon(R.drawable.unblock);
            	
            	String names[] = new String[block.size()];
            	for (int i = 0; i < block.size(); i++)
            		names[i] = block.get(i).getname();
            	
            	builder.setItems(names, new DialogInterface.OnClickListener() {
            	    public void onClick(DialogInterface dialog, int item) {  
            	    	uiactivity.addevent(block.get(item));            	    	
            	    	Toast.makeText(uiactivity,String.format(uiactivity.getString(R.string.block_nomore), block.get(item).getname()), Toast.LENGTH_SHORT).show();
    					unblock(block.get(item));
            	    	
            	    	updateview();
            	    }
            	});
            	AlertDialog alert = builder.create();
            	alert.show();
			}
		});		
		return view;
	}

	@Override
	public void updateview() {
		if (view == null) return;
		view.post(new Runnable() {
			@Override
			public void run() {
				tvname.setText(name + " (" + block.size() + ")");				
			}			
		});
	}
	
	public void block(BTEvent btevent) {
		block.add(btevent);
		updateview();
	}
	
	public void unblock(BTEvent btevent) {
		block.remove(btevent);
		if (block.size() == 0)
			uiactivity.removeEvent(this);
		else updateview();		
	}

	@Override
	public String getinfo() {		
		return String.format(uiactivity.getString(R.string.about_block), block.size(), counter);
	}

	public void onCreateContextMenu(ContextMenu menu) {
		menu.add(0, UNBLOCKALL, 0, uiactivity.getString(R.string.unblockall));
	}
	
	public boolean onContextItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case UNBLOCKALL:
			for (int i = 0; i < block.size(); i++)
				uiactivity.addevent(block.get(i));
			uiactivity.removeEvent(this);
    		return true;
    		default: return false;
		}
	}
	
	public void save(Editor editor, String prefix) {
		editor.putString(prefix + "/type", "BlockEvents");
		editor.putString(prefix + "/name", name);
		editor.putInt(prefix + "/count", block.size());
		
		for (int i = 0; i < block.size(); i++)
			block.get(i).save(editor, prefix + "/block/" + i);
	}

	@Override
	public void load(SharedPreferences settings, String prefix) {
		int count = settings.getInt(prefix + "/count", 0);
		for (int i = 0; i < count; i++)
			block.add(BTEvent.load(settings, prefix + "/block/" + i, uiactivity));		
	}
	
}
