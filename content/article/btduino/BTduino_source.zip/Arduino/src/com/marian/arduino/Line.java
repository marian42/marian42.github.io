package com.marian.arduino;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.View;
import android.widget.TextView;

class Line {
	private String content;
	private boolean out;
	private TextView tv;
	
	public Line(String content, boolean out) {
		this.content = content;
		this.out = out;
	}
	
	public void append(String s) {
		content += s;
		
		if (content.startsWith("\n"))
			content = content.substring(1);
		
		updateview();		
	}
	
	public TextView createView(Context context) {
		tv = new TextView(context);
		tv.setTypeface(Typeface.MONOSPACE);
		tv.setIncludeFontPadding(false);
    	if (!content.endsWith("\n"))
    		tv.setText(content);
    	else tv.setText(content.substring(0, content.length()-1));
    	if (out) tv.setTextColor(Color.rgb(45, 122, 143));	    	
    	return tv;
	}
	
	public void setoutvisibility(boolean visible) {
		if (out) 
			if (tv != null)
				try {
					tv.setVisibility((visible ? View.VISIBLE : View.GONE));
				} catch (Exception e) {};
	}
	
	public String getContent() {
		return content;
	}
	
	public void setContent(String s) {
		content = s;
	}
	
	public boolean getout() {
		return out;
	}
	
	public TextView getView() {
		return tv;
	}
	
	public TextView getView(Context context) {
		if (tv != null) return tv;
		return createView(context);
	}
	
	public void updateview() {
		if (tv != null)
			tv.post(new Runnable() {
				@Override
				public void run() {
					try {
						if (!content.endsWith("\n"))
				    		tv.setText(content);
				    	else tv.setText(content.substring(0, content.length()-1));			    	
					} catch (Exception e) {e.printStackTrace();};					
				}
			});			
	}
}