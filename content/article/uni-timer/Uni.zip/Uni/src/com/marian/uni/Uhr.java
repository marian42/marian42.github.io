package com.marian.uni;

import android.os.Bundle;
import android.app.ActionBar;
import android.app.Activity;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Bitmap.Config;
import android.graphics.Paint.Style;
import android.graphics.drawable.ColorDrawable;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class Uhr extends Activity {
	private ClockView clockview;
	
	private static Timer timer;
	private static boolean editmode = false;
	
	private TextView tvname;
	private EditText etname;
	private ImageButton ibedit;	
	
	private MenuItem mict;
	private MenuItem milonger;
	private MenuItem mivibrate;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	
		setContentView(R.layout.activity_clock);
				
		LinearLayout llmain = (LinearLayout) this.findViewById(R.id.llmain);
		
		if (timer == null)
			timer = new Timer(this);
		
		clockview = new ClockView(this,timer);
		if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE)
			clockview.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.MATCH_PARENT));
		else clockview.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
		llmain.addView(clockview);
		
		//set the actionbar to use the custom view (can also be done with a style)
		getActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);

		//set the custom view to use
		getActionBar().setCustomView(R.layout.actionbar);
		
		
		tvname = (TextView) findViewById(R.id.tvname);
		etname = (EditText) findViewById(R.id.etname);
		ibedit = (ImageButton) findViewById(R.id.ibedit);
		if (mict == null) Log.e("menu","menu");
		
		etname.setImeActionLabel("Fertig", KeyEvent.KEYCODE_ENTER);
		seteditmode(editmode);
		ibedit.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				seteditmode(!editmode);				
				if (editmode) {
					etname.setText(timer.name);
					etname.selectAll();
					etname.requestFocus();
					InputMethodManager keyboard = (InputMethodManager)getSystemService(etname.getContext().INPUT_METHOD_SERVICE);
				    keyboard.showSoftInput(etname, 0);
				}
				else {
					timer.name = etname.getText().toString();
					tvname.setText(timer.name);
					timer.save();
					InputMethodManager imm = (InputMethodManager)getSystemService(etname.getContext().INPUT_METHOD_SERVICE);
					imm.hideSoftInputFromWindow(etname.getWindowToken(), 0);
					// TODO save
				}								
			}
		});
	}
		
	public void updatemenuitems() {
		mict.setTitle(timer.ct ? "CT" : "ST");
		milonger.setTitle(timer.longer ? "95" : "90");
		mivibrate.setTitle(timer.vibrate ? "VIBR AN" : "VIBR AUS");
	}
	

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.uhr, menu);
		mict = menu.findItem(R.id.action_quarter);
		milonger = menu.findItem(R.id.action_duration);
		mivibrate = menu.findItem(R.id.action_vibrate);
		updatemenuitems();
		return true;
	}
	
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.action_duration: {
				timer.longer = !timer.longer;
				timer.save();
				timer.skip = true;
				updatemenuitems();
				break;
				}
		case R.id.action_quarter: {
			timer.ct = !timer.ct;
			updatemenuitems();
			timer.save();
			timer.skip = true;
			break;
			}
		case R.id.action_vibrate: {
			timer.vibrate = !timer.vibrate;
			updatemenuitems();
			timer.save();
			break;
			}
		}
		return true;
	}
	
	void seteditmode(boolean newmode) {
		editmode = newmode;
		tvname.setText(timer.name);
		tvname.setVisibility(editmode ? View.GONE : View.VISIBLE);
		etname.setVisibility(editmode ? View.VISIBLE : View.GONE);
		ibedit.setImageResource(editmode ? R.drawable.done : R.drawable.edit);		
	}
	
	void onload() {
		this.runOnUiThread(new Runnable() {
			@Override
			public void run() {
				updatemenuitems();
				tvname.setText(timer.name);
			}			
		});
	}
	
	


}
