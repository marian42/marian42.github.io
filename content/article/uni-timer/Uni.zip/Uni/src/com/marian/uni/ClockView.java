package com.marian.uni;

import java.util.Calendar;
import java.util.Date;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Bitmap.Config;
import android.graphics.Paint.Align;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;

public class ClockView extends ImageView {
	Bitmap bmp;
	int bgcolor = 0;
	int border = 40;
	private Timer timer;
	private static Typeface roboto_thin;
	private static Typeface roboto_condensed;
	boolean highlight = false;
	
	public ClockView(Context context, Timer timer) {
		super(context);			
		this.timer = timer;
		
		if (roboto_thin == null)
			roboto_thin = Typeface.createFromAsset(this.getContext().getAssets(), "font/Roboto-Thin.ttf");
		if (roboto_condensed == null)
			roboto_condensed = Typeface.createFromAsset(this.getContext().getAssets(), "font/RobotoCondensed-Bold.ttf");
		setOnTouchListener(new View.OnTouchListener() {			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				if (event.getAction() == MotionEvent.ACTION_DOWN) {
					highlight = true;
					((ClockView)v).timer.mode = !((ClockView)v).timer.mode;
					((ClockView)v).timer.save();
				}
				if (event.getAction() == MotionEvent.ACTION_UP) {
					highlight = false;
				}
				return true;
			}
		});
	}	

	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		timer.update();
		
		Paint paint = new Paint();
		paint.setAntiAlias(true);
        
        if (bgcolor == 0) {
        	TypedArray array = this.getContext().getTheme().obtainStyledAttributes(new int[] {  
        			   android.R.attr.colorBackground,
	        	}); 
	    	bgcolor = array.getColor(0, 0xFF00FF); 
	    	array.recycle();
        	}
        	 
		int width = getWidth();
		border = (int) (width * 0.1);
		
		paint.setColor(bgcolor);	
		paint.setStyle(Style.STROKE);
		//canvas.drawRect(0, 0, getHeight(), getHeight(), paint);
		
		paint.setColor(Color.WHITE);
		paint.setStrokeWidth(10);		
		
		canvas.drawCircle((float)(width / 2), (float) (width / 2), (float) (width / 2 - border), paint);
		paint.setColor(Color.rgb(255, 68, 68));
		paint.setStrokeWidth(11);		
		canvas.drawArc(new RectF(border,border,width - border,width - border), -90, (float) (360.0 * timer.progress), false, paint);
		
		paint.setStyle(Style.FILL);
		
		double angle = 2 * Math.PI * timer.progress - Math.PI / 2;
		double sx = width / 2 + (width / 2 - border) * Math.cos(angle);
		double sy = width / 2 + (width / 2 - border) * Math.sin(angle);
		
		int r = 20;
		
		Path path = new Path();
		path.moveTo((float)(sx + r * Math.cos(angle)),(float)(sy + r * Math.sin(angle)));		
		for (int i = 1; i < 4; i++) 
			path.lineTo((float)(sx + r * Math.cos(angle + i * Math.PI / 2)),(float)(sy + r * Math.sin(angle + i * Math.PI / 2)));		
		paint.setStyle(Style.FILL);
		
		canvas.drawPath(path, paint);
		
		
		
		
		if (!highlight) paint.setColor(Color.WHITE);
		
		paint.setTypeface(roboto_thin);
		paint.setTextSize(150);
		paint.setTextAlign(Align.LEFT);
		
		
		String text1 = ((int)(timer.progress * 100) == 0 && timer.progress < 0 ? "-" : "") + String.valueOf((int)(timer.progress * 100));
		int m = Math.abs((int)(timer.progress * 10000) % 100);
		String text2 = "." + (m < 10 ? "0" : "") + m + "%";
		
		if (timer.mode) {
			if (timer.remaining < 0) timer.remaining = -timer.remaining;
			text1 = (timer.remaining > 60 * 60 * 1000 ? String.valueOf((int)(timer.remaining / (60 * 60 * 1000))) + ":"  + ((int)(timer.remaining / (60 * 1000)) % 60 < 10 ? "0" : ""): "") + ((int)(timer.remaining / (60 * 1000)) % 60) + ":" + ((int)(timer.remaining / (1000)) % 60 < 10 ? "0" : "") + ((int)(timer.remaining / (1000)) % 60);
			text2 = "." + ((int)(timer.remaining / 10) % 100 < 10 ? "0" : "") + String.valueOf((int)((timer.remaining / 10) % 100));
		}
		
		String s1 = "";
		String s2 = "";
		for (int i = 0; i < text1.length(); i++)
			if (text1.charAt(i) == '.' || text1.charAt(i) == ':' || text1.charAt(i) == '-' || text1.charAt(i) == '%')
				s1 += text1.charAt(i);
			else s1 += '8';
		for (int i = 0; i < text2.length(); i++)
			if (text2.charAt(i) == '.' || text2.charAt(i) == ':' || text2.charAt(i) == '-' || text2.charAt(i) == '%')
				s2 += text2.charAt(i);
			else s2 += '8';
		
		Rect r1 = new Rect();
		Rect r2 = new Rect();
		
		double s = 100;
		do {			
			paint.setTextSize((float) s);
			paint.setTypeface(Typeface.DEFAULT_BOLD);
			paint.getTextBounds(s1, 0, s1.length(), r1);
			paint.setTextSize((float) (s / 2));
			paint.setTypeface(roboto_thin);
			paint.getTextBounds(s2, 0, s2.length(), r2);
			s *= 1.1;
		}
		while (r1.width() + r2.width() + 20 < width - 4 * border);
		s /= 1.1;
		
		paint.setTextSize((float) s);
		paint.setTypeface(Typeface.DEFAULT_BOLD);
		paint.setTextAlign(Align.RIGHT);
		canvas.drawText(text1, width / 2 - (r1.width() + r2.width()) / 2 + r1.width(), width / 2 + r1.height() / 2, paint);
		paint.setTextSize((float) (s / 2));
		paint.setTypeface(roboto_thin);
		paint.setTextAlign(Align.LEFT);
		canvas.drawText(text2, width / 2 - (r1.width() + r2.width()) / 2 + r1.width(), width / 2 + r1.height() / 2, paint);
		
		Calendar b = Calendar.getInstance();
		b.setTimeInMillis(timer.begin);
		Calendar e = Calendar.getInstance();
		e.setTimeInMillis(timer.end);
		
		
		String beginend = String.format("%02d:%02d - %02d:%02d", b.get(Calendar.HOUR_OF_DAY), b.get(Calendar.MINUTE),e.get(Calendar.HOUR_OF_DAY),e.get(Calendar.MINUTE));
		paint.setTextSize((float) (width * 0.05));
		if (!highlight) paint.setColor(Color.rgb(144, 144, 144));
		paint.setTypeface(roboto_condensed);
		paint.setTextAlign(Align.CENTER);
		canvas.drawText(beginend, width / 2, width / 2 + r1.height() / 2 + paint.getTextSize() + 30, paint);		
		
		this.invalidate();
	}

	
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		this.setAdjustViewBounds(true);
		if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE)
			this.setMeasuredDimension(MeasureSpec.getSize(heightMeasureSpec), MeasureSpec.getSize(heightMeasureSpec));
		else this.setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), MeasureSpec.getSize(widthMeasureSpec));
	}
	

}
