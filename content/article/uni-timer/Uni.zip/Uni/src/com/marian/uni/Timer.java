package com.marian.uni;

import java.util.Calendar;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Vibrator;
import android.text.format.Time;

public class Timer {
	long begin;
	long end;
	double progress;
	long remaining;
	
	// Prefs
	String name;
	boolean ct;
	boolean longer;
	boolean vibrate;
	boolean mode;
	
	int stage;
	int hour;
	int day;
	
	long lastrefresh;
	long now;
	int slot;
	
	Uhr context;
	
	boolean skip = false;
	
	public Timer(Uhr context) {
		name = "Uni";
		ct = true;
		longer = false;
		vibrate = false;
		mode = true;
		stage = -1;
		lastrefresh = System.currentTimeMillis();
		this.context = context;
	}
	
	void update() {
		now = System.currentTimeMillis();
		Calendar c = Calendar.getInstance();
		
		begin = now - now % (60 * 60 * 1000) + (ct ? 15 * 60 * 1000 : 0);
		if (c.get(Calendar.HOUR_OF_DAY) % 2 == 1) begin -= 60 * 60 * 1000;		
		end = begin + (longer ? 95 : 90) * 60 * 1000;		
		progress = (double)(now - begin) / (end - begin);
		remaining = end - now;
		
		hour = c.get(Calendar.HOUR_OF_DAY) / 2;
		day = c.get(Calendar.DAY_OF_WEEK);
		
		int newslot = day * 12 + hour;
		
		int newstage = 0;
		if (now < begin) newstage = 0;
		else if (now < (end + begin) / 2) newstage = 1;
		else if (now < end) newstage = 2;
		else newstage = 3;
		
		if (stage != newstage) {
			int old = stage;
			stage = newstage;
			if (old == -1) load();
			else if (!skip)
				onchangestate();
		}
		
		if (slot != newslot) load();
		slot = newslot;
	
		skip = false;
		lastrefresh = now;
	}
	
	void onchangestate() {		
		if (stage == 0) load();
		if ((stage == 1 || stage == 2 || stage == 3) && vibrate && now - lastrefresh < 1000) {
			Vibrator v = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
			long[] pattern = {100,100,100,100,100};
			v.vibrate(pattern,-1);
		}
	}
	
	void save() {
		SharedPreferences prefs = context.getSharedPreferences("uniclock", Context.MODE_PRIVATE);
		SharedPreferences.Editor editor = prefs.edit();
		String prefix = String.valueOf(day) + "-" + String.valueOf(hour) + "-";
		editor.putString(prefix + "name", name);
		editor.putBoolean(prefix + "ct", ct);
		editor.putBoolean(prefix + "longer", longer);
		editor.putBoolean("vibrate", vibrate);
		editor.commit();
	}
	
	void load() {
		SharedPreferences prefs = context.getSharedPreferences("uniclock", Context.MODE_PRIVATE);
		String prefix = String.valueOf(day) + "-" + String.valueOf(hour) + "-";
		name = prefs.getString(prefix + "name", "Uni");
		ct = prefs.getBoolean(prefix + "ct", ct);
		longer = prefs.getBoolean(prefix + "longer", longer);
		vibrate = prefs.getBoolean("vibrate", vibrate);
		mode = prefs.getBoolean("mode", mode);
		context.onload();
	}
}
